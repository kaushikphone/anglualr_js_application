$(document).ready(function () {
    alert('sssssss');
})