var categoryIdVal;
var categorySelected = true;
var levelValue = '0';
var flagValue;
var levelDataValue;
function enableCategories(enableFlag){
	for(var categoryIdInt = 1;categoryIdInt <= 4; categoryIdInt++){
		var category_id = 'category' + categoryIdInt.toString();
		var category_btn = document.getElementById(category_id);
		if(category_btn!=undefined && category_btn!=null){
			if(enableFlag){
				category_btn.removeAttribute('disabled');
			}else{
				category_btn.setAttribute('disabled','disabled');
			}	
		}
	}
}

function selectOrDeselectCategories(categoryIdValue){
	var categoryIdIntValue = parseInt(categoryIdValue);
	for(var categoryIdInt = 1;categoryIdInt <= 4; categoryIdInt++){
		var category_id = 'category' + categoryIdInt.toString();
		var category_btn = document.getElementById(category_id);
		if(category_btn!=undefined && category_btn!=null){
			if(categoryIdIntValue===categoryIdInt){
				category_btn.setAttribute('class','chat-btn1-selected');
			}else{
				category_btn.setAttribute('class','chat-btn1');
				//category_btn.setAttribute('disabled','disabled');
			}
		}
	}

}

/* function checkTypedCharacter(e){
		e = e || window.event;
		var keyCode = e.keyCode;
		console.log('Typed Key Code::',keyCode);
		if(!(keyCode >= 48 && keyCode <= 57) && keyCode !== 8 && keyCode !== 9 ){
			e.preventDefault();
		}
	}*/
function sendOptionAsPerCategory(){
	categorySelected = false;
	fetchAndShowResponse(categoryIdVal);
	
}
function sendOnlyCategory(categoryIdValue){	
	levelValue = '0';
	categorySelected = true;
	fetchAndShowResponse(categoryIdValue);
}
function fetchAndShowResponse(categoryIdValue){
	console.log('Category Id::',categoryIdValue);
	enableCategories(false);
	categoryIdVal = categoryIdValue;
	selectOrDeselectCategories(categoryIdValue);
	var apigClientFactoryObj = apigClientFactory;
	var newApiClientObj = apigClientFactoryObj.newClient({
		accessKey: '',
		secretKey: '',
		sessionToken: '',
		region: '',
		apiKey: 'OAwayLbIK3atGzZ3T0AuQ86TwTPcydBY6u3nYec6',
		//apiKey: 'V3jlGfRdcE723K9B2DPMJd3ALBTySb25uYLuMr60',
		/*defaultContentType: 'application/json',
		defaultAcceptType: 'application/json'*/
		//application/x-www-form-urlencoded
		defaultContentType: 'application/x-www-form-urlencoded',
		defaultAcceptType: 'application/x-www-form-urlencoded'		
	});
	
	var bodyDataJSON;
	if(categorySelected){
		bodyDataJSON = {
			'category_id': categoryIdValue
		};
	}else{
		var userMsgElmt = document.getElementById('userMsgElmt');
		var optionVal = '';
		if(userMsgElmt!=undefined && userMsgElmt!=null && userMsgElmt.style.display==='block'){
			optionVal = userMsgElmt.value;
		}
		levelValue += (optionVal.length==0)?optionVal:'|'+optionVal;
		bodyDataJSON = {
			'category_id': categoryIdValue,
			'statement': optionVal,
			'level':levelValue
		};
		if(flagValue==1 && levelDataValue==undefined){
			bodyDataJSON = {
				'category_id': categoryIdValue,
				'statement': optionVal
			};
		}
	}
	
	newApiClientObj.chatbotInteractionPost({
	'x-api-key':'OAwayLbIK3atGzZ3T0AuQ86TwTPcydBY6u3nYec6'
	//'x-api-key':'V3jlGfRdcE723K9B2DPMJd3ALBTySb25uYLuMr60'
	},bodyDataJSON).then(function(response){
		console.log(JSON.stringify(response));
		enableCategories(true);
		if(response!=undefined && response!=null && response.status==200){
			var responseData = response.data;
			if(responseData!=undefined && responseData!=null){
				flagValue = (responseData.flag != undefined && responseData.flag != null)?responseData.flag:'';
				levelDataValue = responseData.level;
				
				levelValue = (levelDataValue!=undefined && levelDataValue!=null)?levelDataValue:levelValue;
				var configDataLevelValue = (response.config!=undefined && response.config!=null 
												&& response.config.data!=undefined && response.config.data!=null)?response.config.data.level:undefined;
				console.log('FlagValue::',flagValue);
				console.log('Level Value::',levelDataValue);				
				var statementMsg = responseData.statement;
				var statementDiv = document.getElementById('statementDiv');
				var userMsgElmt = document.getElementById('userMsgElmt');
				var continueMsgDiv = document.getElementById('continueMsgDiv');
				var sendOptionButton = document.getElementById('sendOptionButton');
				var senderNameFld = document.getElementById('senderNameFld');
				if(continueMsgDiv!=undefined && continueMsgDiv!=null){
					if(levelDataValue==undefined && configDataLevelValue==undefined){
						continueMsgDiv.style.display = 'block';
					}else{
						continueMsgDiv.style.display = 'none';
					}
					
				}
				if(statementDiv!=undefined && statementDiv!=null 
					&& statementMsg!=undefined && statementMsg!= null){
					statementDiv.innerHTML = statementMsg;
				}	
					
				if(senderNameFld!=undefined && senderNameFld!=null){
					senderNameFld.style.display = 'block';
				}
				if(userMsgElmt!=undefined && userMsgElmt!=null){
					if(flagValue==1 && levelDataValue!=undefined && levelDataValue==='RESET'){
					//if(flagValue==1){
						userMsgElmt.setAttribute('disabled','disabled');
						userMsgElmt.removeAttribute('placeholder');
					}else if((flagValue==0) || (flagValue==1 && levelDataValue==undefined)){
						//else if(flagValue==0){
						//userMsgElmt.value = '';
						userMsgElmt.removeAttribute('disabled');
						userMsgElmt.setAttribute('class','option-text-bottom');						
						userMsgElmt.style.display='block';
						userMsgElmt.setAttribute('placeholder','Type here');
						userMsgElmt.focus();
					}	
					userMsgElmt.value = '';
				}
				if(sendOptionButton!=undefined && sendOptionButton!=null){
					if(configDataLevelValue!=undefined && flagValue==1){
						sendOptionButton.setAttribute('disabled','disabled');
					}else if(flagValue==1){
						sendOptionButton.removeAttribute('disabled');
					}
				}
			}
		}
	}).catch(function(error){
		enableCategories(true);
		console.log(JSON.stringify(error));
	});
	//console.log(JSON.stringify(responseJSON));
}