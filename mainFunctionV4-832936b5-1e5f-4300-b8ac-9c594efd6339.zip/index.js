'use strict';

const AWS = require("aws-sdk");
const request=require('request');
const util=require('util');
const crypto = require("crypto");

var kinesis = new AWS.Kinesis();
var docClient = new AWS.DynamoDB.DocumentClient();

const clientAuthDyDBTableName = process.env.gspClientAuthTable;
const requestActionParamDyDBTableName=process.env.gspActionLookupTable;
const gspErrorCodesDyDBTableName=process.env.gspErrorCodeTable;
const gspGeneralConfigDyDBTableName=process.env.gspConfigTable;

const kinesisStreamPartitionKey=process.env.gspKinesisPartitionKey;
const kinesisStreamName=process.env.gspKinesisStreamName;

var arrHeaderParamsToInclude=new Array();
 
console.log('PwC GSP Handler AWS lambda function has been triggered');

exports.handler = function (event,context,callback) {
try
{
    var requestConfig={};
    var gstnRequestHeaderObject={};
    var parsedBodyJSON={};
    var kinesisDataObject={};
   
    var urlQueryParamArr=[];
    var headerParamArr=[]; 

    var gspConfigObject={};
   
    console.log("Event Contents From GSP API Call: \n" + util.inspect(event, {showHidden: false, depth: null}));
      	
	//parsedBodyJSON = isValidJSON(((event.body!=undefined)?event.body:""));
	parsedBodyJSON = ((event.body!=undefined && event.body!=null )?event.body:{});
	
	var requestBodyPayload=(parsedBodyJSON.data!=undefined && parsedBodyJSON.data!=null )? parsedBodyJSON.data:"";	
	var requestBodyPayloadSHA1Hash=crypto.createHash('sha1').update(requestBodyPayload).digest("base64");
	
	var typeOfRequestAction=(Object.keys(parsedBodyJSON).length >0)?((parsedBodyJSON.action==undefined || parsedBodyJSON.action=="")?"":parsedBodyJSON.action)
	                  :((event.queryStringParameters!=undefined)?((event.queryStringParameters.action!=undefined)?event.queryStringParameters.action:""):"");
	                     
	var client_id=(event.headers!=undefined)?
                 ((event.headers["X-Asp-Auth-Token"]!=undefined  && (event.headers["X-Asp-Auth-Token"].match(/:/g) || []).length==3)?(event.headers["X-Asp-Auth-Token"].split(":")[0]):"")
				 :"";

	kinesisDataObject={		
		    typeOfStreamInput:"REQUEST",

			headerTxnNo: (event.headers!=undefined)?((event.headers["txn"]!=undefined) ? event.headers["txn"]:""):"",

			client_name:"",
			client_id: client_id,

			requestTypeAction:typeOfRequestAction,

			username:(event.headers!=undefined)?((event.headers["username"]!=undefined)?event.headers["username"]:(parsedBodyJSON.username!=undefined ? parsedBodyJSON.username:"")):"",
			
	    	requestBodyPayloadHash:requestBodyPayloadSHA1Hash,
			requestHeaderParameters:((event.headers!=undefined)?Object.assign({}, event.headers):{}),
			
			gstnResponseBodyHash:"",			
			gstnResponseErrorCode:"",
			gstnResponseStatusCode:"",
			gstnResponseErrorMessage:"",
			
			serverErrorCode:"",
			serverErrorMessage:""
	};
	
	var dyDBQuery1params = {
    TableName: gspGeneralConfigDyDBTableName
    };	

    docClient.scan(dyDBQuery1params, gspFetchConfigValues);

    function gspFetchConfigValues(err, data) 
    {
    	console.log('Flag 0: Event: Dynamo Db Query #1 Executed. Time elapsed =', 300000-context.getRemainingTimeInMillis());

   		if (err)
   		{
           console.error("Error: Query #1 to Dynamo DB table named "+ gspGeneralConfigDyDBTableName +" failed:", JSON.stringify(err, null, 2));
           fetchErrorCodeFromDynamoDB(18,kinesisDataObject,callback);
		   return;
    	}
        else
    	{
    	  console.log("Success: Query #1 to Dynamo Table named "+ gspGeneralConfigDyDBTableName +" succeeded.");  

      	  if(data==undefined || data.Items==undefined || data.Items.length==0)
      	  {
             	console.log("Error: Query #1: No data found in Dynamo DB Table named :" + gspGeneralConfigDyDBTableName);             	             
      	  	 	fetchErrorCodeFromDynamoDB(19,kinesisDataObject,callback);
			 	return;
      	  }
      	  else
      	  {
      	  		for (var i=0;i<data.Items.length;i++)
      	  		{  
      	  			gspConfigObject[data.Items[i].config_type]=data.Items[i].Value;
      	  		}
      	  		
      	  		arrHeaderParamsToInclude=(gspConfigObject["kinesisStreamRequestHeaderParameters"]).split(",");	

      	  		if(gspConfigObject["logRequestParameters"]=="true")
      	  		{
      	  			pushToKinesisStream(kinesisDataObject);
      	  		}
      	  		else
      	  		{
      	  			console.log("logRequestParameters: False! Hence Not logging API HTTP Request Parameters");
      	  		}

      	  		var isValidPwcHeader=1;

      	  		if (
					(
						isValidPwcHeader=verifyPwCGSPHeaders(
						((event.headers!=undefined)?(event.headers["X-Asp-Auth-Token"]!=undefined?event.headers["X-Asp-Auth-Token"]:""):""),
				    	((event.headers!=undefined)?(event.headers["X-Asp-Auth-Signature"]!=undefined?event.headers["X-Asp-Auth-Signature"]:""):""),
					 	 client_id,
					 	((gspConfigObject["authTokenTimeoutInSeconds"]!=undefined && parseInt(gspConfigObject["authTokenTimeoutInSeconds"])!=NaN && parseInt(gspConfigObject["authTokenTimeoutInSeconds"])>0 ) 
					 	? gspConfigObject["authTokenTimeoutInSeconds"]:300)
					 	                                    )
					) <0
				   ) 
				    
					{	
						fetchErrorCodeFromDynamoDB(isValidPwcHeader,kinesisDataObject,callback);
						return;					
					}
				else
				{ 
					var client_name="";

					var dyDBQuery2params = {
					TableName: clientAuthDyDBTableName,
					Key:{
	     				"client_id": client_id
					}};
			
					docClient.get(dyDBQuery2params, function(err, data)
		 			{ 
						console.log('Flag 1: Event: Dynamo Db Query #2 Executed. Time elapsed =', 300000-context.getRemainingTimeInMillis());
		
						if (err)			
						{	
							console.log("Error: Query #2 to Dynamo DB table named "+ clientAuthDyDBTableName +" Failed!.Error Reason:"+err);				
							fetchErrorCodeFromDynamoDB(13,kinesisDataObject,callback);
							return;
						}	 
						else 
						{									
							if(data.Item==undefined || data.Item.length==0)
							{
								console.log("Error: Query #2 : Client id not registered with GSP ");
								fetchErrorCodeFromDynamoDB(24,kinesisDataObject,callback);
								return;					
							}
							else if( data.Item.client_name==undefined || data.Item.client_name=="")
							{
								console.log("Error: Query #2: Client Name attribute not found for the client id");
								fetchErrorCodeFromDynamoDB(14,kinesisDataObject,callback);
								return;					
							}

							else if( data.Item.client_public_key==undefined || data.Item.client_public_key=="")
							{	
								console.log("Error: Query #2: Client Public Key Not Found In Records");	
								fetchErrorCodeFromDynamoDB(2,kinesisDataObject,callback);
								return;
							}
							else
						    {	
								client_name=data.Item.client_name;
								kinesisDataObject["client_name"]=client_name;
					
								var verifier = crypto.createVerify('sha1');
								verifier.update(event.headers["X-Asp-Auth-Token"]);
					
								var isVerified = verifier.verify(data.Item.client_public_key, event.headers["X-Asp-Auth-Signature"],'base64');
								var isVerified = 1;
								console.log('Flag 2: Auth Token Signature Verification Process Completed. Time elapsed =', 300000-context.getRemainingTimeInMillis());
				
								if(!isVerified)
								{
									console.log("Error: GSP Header Auth Token Signature Verification Failed!!");
									fetchErrorCodeFromDynamoDB(3,kinesisDataObject,callback);
									return;
								}
								else
								{	
									console.log("Success: GSP Header Auth Token Signature Verification Successfull");					
									var actionType="";

									if(((event.requestContext.httpMethod!=undefined)?event.requestContext.httpMethod:"")=="GET")
									{
										actionType=(event.queryStringParameters!=undefined)?(event.queryStringParameters.action!=undefined?event.queryStringParameters.action:""):"";
										if(actionType=="")
										{
												console.log("Error: Action Type Not Defined In URL Query String Parameters for GET Request");
												fetchErrorCodeFromDynamoDB(30,kinesisDataObject,callback);
												return;
										}
										else
										{
											console.log("Success: GSP API GET Request Action Type :"+actionType);
										}
							
									}	
									else
									{							
										if(event.body==undefined || event.body=="")
										{
											console.log("Error: GSP API request body undefined");
											fetchErrorCodeFromDynamoDB(5,kinesisDataObject,callback);	
											return;							
										}
										else if(Object.keys(parsedBodyJSON).length==0)
										{
											console.log("Error: GSP API request body malformed or not a valid JSON object");
											fetchErrorCodeFromDynamoDB(28,kinesisDataObject,callback);
											return;
										}
										else if(parsedBodyJSON.action==undefined || parsedBodyJSON.action=="")
										{gstReturnType
											console.log("Error: GSP API request body has undefined action");
											fetchErrorCodeFromDynamoDB(12,kinesisDataObject,callback);
											return;
										}
										else
										{
											actionType=parsedBodyJSON.action;
										}
									}

									

									var reqPath=(event.requestContext!=undefined && event.requestContext!=null)?((event.requestContext.resourcePath!=undefined && event.requestContext.resourcePath!=null)?event.requestContext.resourcePath:""):"";										
									var reqPathArr=reqPath.split("/");
									var gstReturnType=(reqPathArr!=undefined && reqPathArr!=null)?((reqPathArr[4]!=undefined && reqPathArr[4]!=null)?reqPathArr[4]+"_":((reqPathArr[3]!=undefined && reqPathArr[3]!=null && reqPathArr[3]=="ledgers")?reqPathArr[3]+"_":"")):"";

									var dyDBQuery3PrimaryIndex=(actionType=="LARGE_FILE_DOWNLOAD"?actionType:(gstReturnType+actionType));

									
									var dyDBQuery3params = {
									TableName: requestActionParamDyDBTableName,
									Key:{
										"actionType": dyDBQuery3PrimaryIndex
								 	}};							
								
									//Fetch HTTP Request Headers,GSTN API URL and URL Query Parameters(if any)			
									docClient.get(dyDBQuery3params, function(err, data) 
									{
							  			console.log('Flag 3: Dynamo Db Query #3 Executed .Net time elapsed in milliseconds =', 300000-context.getRemainingTimeInMillis());
							  
							 			if (err) 
										{	
											console.log("Error: Query #3 to Dynamo DB table named "+requestActionParamDyDBTableName +"failed.Error Reason:"+err);
											fetchErrorCodeFromDynamoDB(10,kinesisDataObject,callback);
											return;
										} 
							   			else 
										{
											console.log(" Success: Query #3: Data returned from Dynamo DB table named "+requestActionParamDyDBTableName+" :"+util.inspect(data, {showHidden: false, depth: null}));	
							
											if( data.Item==undefined || data.Item.length==0)
											{
												console.log("Error: Query #3 : No Records Found for Request Action in Dynamo DB")
												fetchErrorCodeFromDynamoDB(29,kinesisDataObject,callback);
												return;
											}								
									
											else if( data.Item.requestHeaderParameters==undefined || data.Item.requestHeaderParameters=="" 	)
											{
												console.log("Error: HTTP Header Parameter Records for Request Action Not Found in Dynamo DB")
												fetchErrorCodeFromDynamoDB(15,kinesisDataObject,callback);
												return;										
											}
											else if (data.Item.gstnAPIURL==undefined || data.Item.gstnAPIURL=="")
											{
												console.log("Error: GSTN API URL Not Found in Dynamo DB");
												fetchErrorCodeFromDynamoDB(8,kinesisDataObject,callback);
												return;
											}
											else if(data.Item.requestType==undefined || data.Item.requestType=="" )
											{
												console.log("Error: GSTN API Request Type Not Found in Dynamo DB");
												fetchErrorCodeFromDynamoDB(25,kinesisDataObject,callback);
												return;

											}

											else	
											{
												var dyDBgstnApiUrlStrModified=data.Item.gstnAPIURL.replace("//",""); 
												var dyDBgstnApiURLResourceStr=dyDBgstnApiUrlStrModified.substring(dyDBgstnApiUrlStrModified.indexOf("/"));

												var eventResourceStr=(event.requestContext!=undefined)?(event.requestContext.resourcePath!=undefined?event.requestContext.resourcePath:""):"";

												if(dyDBgstnApiURLResourceStr!=eventResourceStr && actionType!="LARGE_FILE_DOWNLOAD")
												{
													console.log("Error: Dynamo DB GSTN API URL resource path doesnot match the HTTP request resource path");
													fetchErrorCodeFromDynamoDB(26,kinesisDataObject,callback);
													return;
												}
												else
												{
													console.log("Success: GSTN API URL Resource Path Validated.");
												}

												var reqType=(data.Item.requestType!=undefined)?(data.Item.requestType!=undefined?data.Item.requestType:""):"";
												var eventRequestType=((event.requestContext!=undefined)?(event.requestContext.httpMethod!=undefined?event.requestContext.httpMethod:""):"");

												if(reqType!=eventRequestType)
												{
													console.log("Error: Dynamo Db Request Type Record Doesnot Match GSP HTTP Request Type");
													fetchErrorCodeFromDynamoDB(27,kinesisDataObject,callback);
													return;
												}
												else
												{
													console.log("Success: HTTP Request Type Validated.")
												}

												headerParamArr=data.Item.requestHeaderParameters.split(",");											
											
												for (var i=0;i<headerParamArr.length;i++)						
												{
											
													if(event.headers[headerParamArr[i]]!=undefined )
													{																									
														gstnRequestHeaderObject[headerParamArr[i]]=event.headers[headerParamArr[i]];												
													}
													else
													{
														console.log("Error: GSP API Request Header Parameters Incorrect or Malformed! \n");
														console.log("Missing GSP API Request Header Parameter= "+headerParamArr[i]);										
														fetchErrorCodeFromDynamoDB(6,kinesisDataObject,callback);
														return;
													}							
															
												}
								
												//gstnRequestHeaderObject["Accept"]=event.headers["Accept"];
															
												if(data.Item.urlQueryParameters!=undefined && data.Item.urlQueryParameters!="")
												{						
													if(event.queryStringParameters==undefined || Object.keys(event.queryStringParameters).length==0)
													{
														console.log("Error: GSP API URL query parameters undefined");
														fetchErrorCodeFromDynamoDB(7,kinesisDataObject,callback);
														return;
													}									
													else
													{
														urlQueryParamArr=data.Item.urlQueryParameters.split(",");										
																								
														var urlQueryParametersObject={};
										
														for (var i=0;i<urlQueryParamArr.length;i++)
														{  
															if(event.queryStringParameters[urlQueryParamArr[i]]!=undefined)											
															{														
																urlQueryParametersObject[urlQueryParamArr[i]]=event.queryStringParameters[urlQueryParamArr[i]];        											
															}
															else
															{
																console.log("Error: GSP API URL query parameters incorrect or malformed \n");
																console.log("Missing GSP API Request URL Query Parameter= "+urlQueryParamArr[i]);
																fetchErrorCodeFromDynamoDB(9,kinesisDataObject,callback);
																return;
															}
																										
														}

														if(actionType=="LARGE_FILE_DOWNLOAD")
														{
															var largeFileUrlPathFromWebAPI= (event.requestContext["resourcePath"]!=undefined && event.requestContext["resourcePath"]!="")?event.requestContext["resourcePath"]:"";

															var url="https://api.gsp.vayana.com/gus"+event.headers.urlVayana;

															requestConfig = {
																//uri: data.Item.gstnAPIURL.toString()+event.requestContext["vayanaResourcePath"].toString(),//data.Item.gstnAPIURL.toString()+largeFileUrlPathFromWebAPI,
																uri:data.Item.gstnAPIURL.toString()+largeFileUrlPathFromWebAPI.toString(),
																headers: JSON.parse(JSON.stringify(gstnRequestHeaderObject)),															
																qs:urlQueryParametersObject,
																encoding:null,
																timeout:gspConfigObject["gstnRequestTimeoutInMilliSec"]													
															};

														}
														else
														{

															requestConfig = {
																uri: data.Item.gstnAPIURL.toString(),
																headers: JSON.parse(JSON.stringify(gstnRequestHeaderObject)),
																body: parsedBodyJSON,
																qs:urlQueryParametersObject,
																json:true,
																timeout:gspConfigObject["gstnRequestTimeoutInMilliSec"]													
															};

														}
																		
													}													
											}				
											else
											{						
												requestConfig = {
													uri:data.Item.gstnAPIURL.toString(),
													headers: JSON.parse(JSON.stringify(gstnRequestHeaderObject)),
													body: parsedBodyJSON,
													json:true,
													timeout:gspConfigObject["gstnRequestTimeoutInMilliSec"]
										        };
									        }
																				
									        
											var gstnRequestHandlerFunction = function (err, httpResponse, body) 
											{	
												console.log('Flag 5: Response Received from GSTN. Net time elapsed in milliseconds=', 300000-context.getRemainingTimeInMillis());
								
												if(err)
												{	
													console.log("Error: GSTN API Call Failed! Error Reason: \n"+err);
												
													if(err.code=="ETIMEDOUT" || err=="ESOCKETTIMEDOUT")
													{
														if(err.connect==true )												
														{
															console.log("Error: GSTN connection timed out ");													
															fetchErrorCodeFromDynamoDB(20,kinesisDataObject,callback);
															return;															
														}
														else 
														{
															console.log("Error: GSTN request timed out");													
															fetchErrorCodeFromDynamoDB(21,kinesisDataObject,callback);
															return;
														
														}
													
													}											
												
													fetchErrorCodeFromDynamoDB(4,kinesisDataObject,callback);	
													return;
												}
				
												else
												{
													kinesisDataObject["typeOfStreamInput"]="RESPONSE";

													if(actionType=="LARGE_FILE_DOWNLOAD")
													{
																											
														kinesisDataObject["gstnResponseStatusCode"]="";
														kinesisDataObject["gstnResponseErrorCode"]="";
														kinesisDataObject["requestHeaderParameters"]=gstnRequestHeaderObject;													
														kinesisDataObject["gstnResponseBodyHash"]=crypto.createHash('sha1').update((httpResponse.body!=undefined && httpResponse.body!=null)?httpResponse.body.toString():"").digest("base64");																									
													
														pushToKinesisStream(kinesisDataObject);
																				
														callback(null,{statusCode:200,body:httpResponse.body,headers:httpResponse.headers});
														return;
													}
													else
													{
														
														console.log(' GSTN Response body: ' + util.inspect((httpResponse.body!=undefined?httpResponse.body:{}), {showHidden: false, depth: null}));
										
														kinesisDataObject["gstnResponseStatusCode"]=(httpResponse.body!=undefined)?((httpResponse.body.status_cd!=undefined)? httpResponse.body.status_cd:""):"";
														kinesisDataObject["gstnResponseErrorCode"]=(httpResponse.body!=undefined)?((httpResponse.body.status_cd!=undefined)?((httpResponse.body.status_cd=='0') ? httpResponse.body.error_cd:""):""):"";																								
														kinesisDataObject["requestHeaderParameters"]=gstnRequestHeaderObject;													
														kinesisDataObject["gstnResponseBodyHash"]=crypto.createHash('sha1').update(JSON.stringify(httpResponse.body!=undefined?httpResponse.body:{})).digest("base64");																									
													
														pushToKinesisStream(kinesisDataObject);
																				
														//callback(null,{statusCode:200,body:JSON.stringify(httpResponse.body)});
														callback(null,{statusCode:200,body:httpResponse.body});
														return;


													}

												}
							                }; //end of gstn API call function definition							
													
									
											console.log('Flag 4: Request To GSTN To Be Sent. Net time elapsed in milliseconds =', 300000-context.getRemainingTimeInMillis());
											console.log("requestConfig :" + util.inspect(requestConfig, {showHidden: false, depth: null}));	
											
											switch(reqType)
											{
												case "GET":
													request.get(requestConfig, gstnRequestHandlerFunction);
													break;
												case "PUT":
													request.put(requestConfig, gstnRequestHandlerFunction);
													break;
												case "POST":
													request.post(requestConfig, gstnRequestHandlerFunction);
													break;							 
												default:
													console.log("Error: Dynamo Db HTTP Request Action Type Not of Type POST/GET/PUT!");
													fetchErrorCodeFromDynamoDB(31,kinesisDataObject,callback);													
													return;
												
											}//end of switch case	
						            						
									}// end of nested if-else of else in inner dynamo db function  
									
						        }// end of if-else inner dynamo db API call success function
								
					        });//end of inner dynamodb function definition
				
			    }//end of if-else Client Signature Verification
				
		   }// end of if-else GSP Auth Token contents verification 
			
		}//end of if-else else of outer dynamo-db API call success function 
		
	}); //end of outer dynamo db API function definition	
   
   }//end of client-id verification if-else success function
  
  }//end of nested if-else of gspFetchConfigValues()
 
 }//end of else of non error gspFetchConfigValues() if-else

};//end of gspFetchConfigValues() definition

}//end of try block

catch(ex)
 {
	console.log("Error: Exception Encountered in Lambda Function. Error Reason: "+ex);
	fetchErrorCodeFromDynamoDB(0,kinesisDataObject,callback);
	return;
 }
 
}; //end of lambda handler function

function verifyPwCGSPHeaders(pwCGSPAuthToken,signedAuthToken,client_id,timeoutInSeconds)
{
  try
  {
	  
	if(pwCGSPAuthToken=="")
	{
		console.log("Error: Auth Token Undefined");
        return(-1);		
	}
	else if(signedAuthToken=="")
	{
		console.log("Error: Auth Token Signature Undefined");
	    return(-2);	
	}
    else
    {
		var dateTimeErrorCode=1;
		var pwCAuthTokenArray=[];
		pwCAuthTokenArray=pwCGSPAuthToken.split(":");
		
		if((pwCAuthTokenArray.length)!=4)
		{
			console.log("Error: Auth Token malformed or not in desired format");
			return (-3);	
		}
		else if(client_id=="")
		{
			console.log("Error: Auth Token client id undefined");
			return(-11);
		}

		else if(pwCAuthTokenArray[1]==undefined || pwCAuthTokenArray[1]=="")
		{
			console.log("Error: Auth Token Transaction Key undefined");
			return (-4);			
		}
		else if(pwCAuthTokenArray[2]==undefined || pwCAuthTokenArray[2]=="")
		{
			console.log("Error: Auth Token Timestamp undefined");
			return (-5);		
		}
		else if(pwCAuthTokenArray[3]==undefined || pwCAuthTokenArray[3]=="")
		{			
	        console.log("Error: Auth token GSTIN ID undefined");
			return(-6);
		}
		else if((dateTimeErrorCode=validateDateTime((pwCAuthTokenArray[2]!=undefined?pwCAuthTokenArray[2]:""),timeoutInSeconds))<0)
		{			
			return(dateTimeErrorCode);
		}
		else{
			console.log("Success: Auth Token Verification Successfull");
			return(1);
		}
	}
 }
 catch(error)
  {
	console.log("Exception: verifyPwCGSPHeaders() has encountered an unhandled exception.Error reason:"+error);
	fetchErrorCodeFromDynamoDB(0,kinesisDataObject,callback);
	return;
  }
  
 };	

function validateDateTime( dateStr,timeoutInSeconds){
try
{
	if(dateStr.length!=18)
	{
		console.log("Error: Auth token datetime string length not equal to 18");
		return (-7);
	}
	else if(([...dateStr].filter( e => isFinite(e)).join(''))!=dateStr)
	{
		console.log("Error: Auth token datetime string contains non numeric characters");
		return (-8);
	} 
	else
	{  
		var year  = dateStr.slice(0,4);
		var month = dateStr.slice(4,6);
		var day  = dateStr.slice(6,8); 
		var hours  = dateStr.slice(8,10);
		var minutes  = dateStr.slice(10,12);
		var seconds=dateStr.slice(12,14); 
		var milliseconds=dateStr.slice(14,18);
	
		var dateStringFromParts = year + "-" + month + "-" + day+" "+hours+":"+minutes+":"+seconds;

		var date_from_headers = new Date(dateStringFromParts);
		
		if(date_from_headers=="Invalid Date" || date_from_headers==undefined)
		{
			console.log("Error: Auth token Timestamp not a valid datetime value !!");
			return(-9);		
		}
		else
		{
			var currentDateTimeGMT=new Date();
			var currentDateTimeIST = new Date();
		
			currentDateTimeIST.setMinutes(currentDateTimeGMT.getMinutes()+330);

			var difference=(Math.abs(currentDateTimeIST-date_from_headers))/1000;

			if(difference > timeoutInSeconds)
			{
				console.log("Error: Auth token Timestamp datetime older than preset limit of "+timeoutInSeconds.toString()+" seconds");
				return (-10);
			}		
			else
			{
				console.log("Success: Auth token timestamp validation successful!")
				return (1);
			}		
		}
	}
 }//end of try
 
 catch(error)
 {
	console.log("Exception: validateDateTime() has thrown an exception.Error reason:"+error);
	fetchErrorCodeFromDynamoDB(0,kinesisDataObject,callback);	
	return;
 }
 
};

function pushToKinesisStream(kinesisObject)
{
 try
  {
	
	var currentDateTimeIST = new Date();  
	var currentDateTimeGMT = new Date();
  
	currentDateTimeIST.setMinutes(currentDateTimeGMT.getMinutes()+330);  
  
	var timeStampFormatted=currentDateTimeIST.toLocaleDateString()+" "+currentDateTimeIST.toLocaleTimeString();
	kinesisObject['timeStampFormatted']=timeStampFormatted;

	var formattedKinesisObject =formatKinesisPayload(JSON.parse(JSON.stringify(kinesisObject)));

	if(formattedKinesisObject.error=="true")
		{
			console.log("Error: Kinesis response headers couldnot be formatted.")
			fetchErrorCodeFromDynamoDB(0,formattedKinesisObject,callback);
			return;			
		}
	else
		{
			console.log("Formatted Kinesis Data Object:"+util.inspect(formattedKinesisObject, {showHidden: false, depth: null}));
  
			var stringifiedKinesisPayload = JSON.stringify(formattedKinesisObject);
  
			var kinesisPutParams = {
			Data: stringifiedKinesisPayload,
			PartitionKey: kinesisStreamPartitionKey,
			StreamName: kinesisStreamName,
			};	
  
			kinesis.putRecord(kinesisPutParams, (err, data) => {
				if (err)
				{
					console.log("Error: Kinesis Stream PUT Function Error Encountered!!Error Reason: "+err);	  		
					fetchErrorCodeFromDynamoDB(11,formattedKinesisObject,callback);										
					return;
				}		
				else 
				{
					console.log("Success: Kinesis Stream PUT Function Response"+util.inspect(data, {showHidden: false, depth: null}));
					return;
				}
			});
			
		}			
	
  }//end of try
  catch(error)
  {
	  console.log("Exception: pushToKinesisStream() has thrown an exception.Error reason: "+error);
	  fetchErrorCodeFromDynamoDB(0,formattedKinesisObject,callback);
	  return;	  
  }
	
};
	
function fetchErrorCodeFromDynamoDB(errIndex,kinesisDataObject,callback)
{
  try
  {	

	kinesisDataObject["typeOfStreamInput"]="GSPERROR";
	
	var dyDBQuery4params = {
    TableName: gspErrorCodesDyDBTableName,
    Key:{
        "pwcErrCodeIndex": errIndex.toString()
    }};
	
	//Fetch details(client name and Public Key) of client from Dynamo DB table named  clientAuthDyDBTableName
	
	docClient.get(dyDBQuery4params, function(err, data)
	{
			if (err)
			{
				console.log("Error: Query #4 to Dynamo Db table "+gspErrorCodesDyDBTableName+" named  failure reason: " + util.inspect(err, {showHidden: false, depth: null}));
				kinesisDataObject["serverErrorCode"]="GINSER263";
				kinesisDataObject["serverErrorMessage"]="Dynamo DB Error! Query to table named gspErrorCodes has thrown an error.Error Reason: "+err.toString();
						
			}
			else
			{				
				if (data.Item==undefined || Object.keys(data.Item).length==0 )
					{
						console.log("Error: Error Code Index Not Found");
						kinesisDataObject["serverErrorCode"]="GINSER259";
						kinesisDataObject["serverErrorMessage"]="No Error Code Records found in Dynamo DB Table named gspErrorCodes for index= "+errIndex.toString();

					}
				else if (data.Item.gspErrorCode==undefined || data.Item.gspErrorCode=="")
					{
						console.log("Error: No Error Code Defined For Index="+ index.toString());
						kinesisDataObject["serverErrorCode"]="GINSER260";
						kinesisDataObject["serverErrorMessage"]="No gspError attribute record found in Dynamo DB Table named gspErrorCodes for index= "+errIndex.toString();
				
					}
				else if(data.Item.gspErrorMessage==undefined || data.Item.gspErrorMessage=="")
					{
						console.log("Error: No Error Message Defined For Index="+ index.toString());
						kinesisDataObject["serverErrorCode"]="GINSER261";
						kinesisDataObject["serverErrorMessage"]="No gspErrorMessage attribute record found in Dynamo DB Table named gspErrorCodes for index= "+errIndex.toString();
					}
				else if(data.Item.gspAPIResponseCode==undefined || data.Item.gspAPIResponseCode=="")
					{
						console.log("Error: No API Response Error Status Code For Index="+ index.toString());
						kinesisDataObject["serverErrorCode"]="GINSER262";
						kinesisDataObject["serverErrorMessage"]="No API Response Error Status Code attribute record found in Dynamo DB Table named gspErrorCodes for index= "+errIndex.toString();
					}
				else				
					{	console.log("Dynamo DB Query 4: Error Code Parameters Are Valid");
					
						console.log("GSP Response Object:"+util.inspect({"errorCode":data.Item.gspErrorCode,
																		 "errorMessage":data.Item.gspErrorMessage,
																		 "statusCode":data.Item.gspAPIResponseCode}, 
																		{showHidden: false, depth: null}));
						
						if(errIndex!=11)
						{
							kinesisDataObject["serverErrorCode"]=data.Item.gspErrorCode;
							kinesisDataObject["serverErrorMessage"]=((data.Item.gspAPIResponseCode!=500)? data.Item.gspErrorMessage:(data.Item.gspInternalErrorMessage!=undefined?data.Item.gspInternalErrorMessage:data.Item.gspErrorMessage));
							pushToKinesisStream(kinesisDataObject);
						}
						else
						{
							console.log("Error: AWS Kinesis Service error hence server error message cannot be logged.");
						}


						callback(null,{statusCode:data.Item.gspAPIResponseCode, body:JSON.stringify({errorCode:data.Item.gspErrorCode,errorMessage:data.Item.gspErrorMessage})});
						return;
					}			
			}//end of if-else

			if(errIndex!=11)
			{
				pushToKinesisStream(kinesisDataObject);			
			}
			else
			{
				console.log("Error: AWS Kinesis Service error hence server error message cannot be logged.");
			}

			callback(null,{statusCode:500, body:JSON.stringify({errorCode:"GINSER246",errorMessage:"GSP Internal server error.Please contact GSP system admin."})});
			return;
	});
  }
  catch(error)
  {
	console.log("Exception: fetchErrorCodeFromDynamoDB() has thrown an exception.Error reason: "+error);
	callback(null,{statusCode:500, body:JSON.stringify({errorCode:"GINSER246",errorMessage:"GSP Internal server error.Please contact GSP system admin."})});
	return;
  }
};

function isValidJSON(eventBodyString)
{
    try
	{
        var jsonObject=JSON.parse(eventBodyString);
		console.log("Success: JSON Parsed Event Body : " + util.inspect(jsonObject, {showHidden: false, depth: null}));
        return (jsonObject);
    }
    catch (error)
	{
	  console.log("Error: isValidJSON() : Event Body String Not A Valid JSON. Error Reason:"+error);
      return ({});
    }
};

function formatKinesisPayload(kinesisPayloadObject)
{
    try
	{
		var formattedKinesisPayload=Object.assign({}, kinesisPayloadObject);
		formattedKinesisPayload["requestHeaderParameters"]={};	

		var headerParamObject = {};
		var keysOfHeaderObject=Object.keys(kinesisPayloadObject.requestHeaderParameters);

		for(var i=0;i<keysOfHeaderObject.length;i++)
		{
   			headerParamObject[keysOfHeaderObject[i].toLowerCase()] = kinesisPayloadObject.requestHeaderParameters[keysOfHeaderObject[i]];
		} 
		
		console.log("headerParamObject: \n" + util.inspect(headerParamObject, {showHidden: false, depth: null}));
        
		for (i=0;i<arrHeaderParamsToInclude.length;i++)
		{
			if((Object.keys(headerParamObject)).indexOf(arrHeaderParamsToInclude[i].toLowerCase())!=-1)
			{
				var temp=headerParamObject[arrHeaderParamsToInclude[i]];
				formattedKinesisPayload.requestHeaderParameters[arrHeaderParamsToInclude[i].replace(/-/g, '_')]=(temp!==null && temp!==undefined)?temp:"";  
			}
			else
			{
				formattedKinesisPayload.requestHeaderParameters[arrHeaderParamsToInclude[i].replace(/-/g, '_')]="";
			}
		}
		
		console.log("formattedKinesisPayload: \n" + util.inspect(formattedKinesisPayload, {showHidden: false, depth: null}));
		return (formattedKinesisPayload);
	}
	catch(error)
	{
		console.log("Exception in formatKinesisPayload() : Response header object attributes could not be formatted.Error reason:"+error);
		return({"error":"true"});
	}
};