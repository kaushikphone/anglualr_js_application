import { Component, OnInit } from '@angular/core';
import {ApiService} from '../HttpService/ApiService';
import { Menu } from '../HttpService/menu';
import { Observable } from 'rxjs/Observable';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import * as $ from 'jquery';
@Component({
  selector: 'pm-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css','./fixedMenu.css'],
  providers:[ApiService]  
})
export class MenuComponent implements OnInit {
  errorMessage: String;
  dtOrgList: Array<any>;
  _fetchMenu: Menu[];
  private results: Observable<Menu[]>;
  constructor(
    private apiSerivce: ApiService,
    
  ) { }

  ngOnInit() {
    this.showHideMenu();
    this.menuFetchFromJson();
    $('.overlayBar').on('click',function(){
      $('#Menusidebar').removeClass('active');
      $('.overlayBar').fadeOut();
  })
  }
  MenuOpening(){
    $('#Menusidebar').toggleClass('active');
    $('.overlayBar').fadeIn();
  }
  showHideMenu(){
    $(".LeftBarMenu").hover(function(){
      $('.leftBox').stop().animate({width: '300px'},800);
      $("#fixedLayer").show();
      $(this).find(".nameShowHide").show().animate({display:'table'});
      }, function(){
      $('.leftBox').stop().animate({width: '100%'},800);
      $("#fixedLayer").hide();
      $(this).find(".nameShowHide").hide().animate({display:'flex'});
  
  });
  }
  menuFetchFromJson(){
    debugger
    this.apiSerivce.getMenuList()
    .subscribe(
        resultArray => this._fetchMenu = resultArray,
        error => this.errorMessage=<any> error,
    )
  }
  
  
}
