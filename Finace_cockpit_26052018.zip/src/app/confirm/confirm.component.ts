import { Component} from '@angular/core';
import { DialogComponent, DialogService } from "ng2-bootstrap-modal";
import { AreaSplineObj } from '../HttpService/menu';
import { Chart } from 'angular-highcharts';
import { ApiService } from '../HttpService/ApiService';
export interface ConfirmModel {
  title:string;
  message:string;
  MavericCardSplitValue:any;
  PeriodValue:string;
  DisputedAmount:number[];
  DisputePeriod:string[];
}
@Component({
  selector: 'pm-confirm',
  templateUrl: './confirm.component.html',
  styleUrls: ['./confirm.component.css'],
  providers:[ApiService,AreaSplineObj]
})
export class ConfirmComponent extends DialogComponent<ConfirmModel, boolean> implements ConfirmModel {
  areaChartSplineMaverickSpend:Chart;
  title: string;
  OptionVal:number;
  year:number;
  message: string;
  msg:string;
  MavericCardSplitValue:any;
  DisputedAmount:number[];
   DisputePeriod:string[];
  PeriodValue:string;
  errorMessage:string;
  spendTomargin:string[]=["Spend to Margin","Spend/COGS/Margin"];
  ColorArray=["#e0301e","#d93954","#602320","#d04a02","#817a64"];
  matchingArray=["Maverick spend","Dispute Invoice","Potential Savings","Suspicious Invoice"];
  DeepCopy:any;
  bgHeader:any[]=[
    {
      'color':'red'
    }
  ];
  constructor(
    dialogService: DialogService,
    private apiSerivce: ApiService,
  ) {
    super(dialogService);

    console.log("mavrickSpl:"+this.MavericCardSplitValue);
  }
  confirm() {
    this.result = true;
    this.close();
  }
  ngOnInit() {
          this.areaChartSplineMaverickSpend=new Chart((new AreaSplineObj()).optionsBar);
          this.areaChartSplineMaverickSpend.options.chart.height=250;
          this.areaChartSplineMaverickSpend.options.series[0].color=this.ColorArray[0];
          this.areaChartSplineMaverickSpend.options.series[0].data=this.MavericCardSplitValue
          this.areaChartSplineMaverickSpend.options.xAxis["categories"]=this.PeriodValue;
  }
}
