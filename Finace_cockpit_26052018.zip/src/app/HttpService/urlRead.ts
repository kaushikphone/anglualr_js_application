
import { environment } from "../../environments/environment";
export class UrlReadJSON{
    optionsBar={
        baseURL:environment.api_url,
        _menuURL:environment.api_url+"/Api/common/getleftmenu",
        _RightSimulationUrl:environment.api_url+"/Api/common/getrightmenu",
        _ComparativeAnalysisURL:environment.api_url+"/api/Chart/GetCompAnaManVsUnmanSpend",
        _LTM_UnmanagedURL:environment.api_url+"/api/Chart/GetLTMUnmanSpendByEntityJSON",
        _LTM_Unmanaged_Spend_VendorURL:environment.api_url+"/api/Chart/GetLTMUnmanSpendByVendor",
        _LTM_Unmanaged_Spend_Material_CategoryURL:environment.api_url+"/api/Chart/GetLTMUnmanSpendByMatCat",
        _getDisputedAmount:environment.api_url+"/api/Chart/GetDisputedAmount",
        _downloadExcel:environment.api_url+"/api/chart/GetExcel"
    }
    
}