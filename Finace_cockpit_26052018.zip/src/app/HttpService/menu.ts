export interface Menu{
    menuId: string;
    menuImage: string;
    menuName: string;
    pageName:string;
    isEnable:boolean;
}
export interface Card{
    CardID:number;
    Year:number;
    Period:number;
    CardName:string;
    CardIcon:string;
    GraphPath:string;
}

export interface RightSimulation{
    menuId:number;
    menuImage:string;
    simulationStateIncrease:string;
    simulationStateDecrease:string;
    isEnable:boolean
}
export interface ComparativeAnalysis{
    Charts_CompAnaManVsUnmanSpendID:number;
    Year:number;
    Period:number;
    CYUnmanagedCol:string;
    CYManagedCol:string;
    VarWithPYUnmanaged:string;
    PieTotSpendCYUnmanaged:string;
    PieTotSpendCYManaged:string;
}
export interface GetCharts_LTMUnmanSpendByBusEntity{
    Charts_LTMUnmanSpendByBusEntityID:number;
    Year:number;
    Period:number;
    Categories:string;
    PYColumnData:string;
    CYColumnData:string;
    VarWithPY:string;
    PieTotSpendCY:string;
    PieTotSpendPY:string;
}
export interface GetCharts_LTMUnmanSpendByMatCatByPeriod{
    Charts_LTMUnmanSpendByMatCatID:number;
    Year:number;
    Period:number;
    MateriaNames:string;
    MaterialValues:string;
    Materials:object;

}
export interface getDisputedAmount{
    DisputedPercentage:string;
    Year:number;
    Period:number;
    DisputedAmount:string;
    TotalDisputedAmount:number;
    TotalDisputePercentage:number;
}
export interface _LTM_Unmanaged_Spend_Vendor{
    year:number,
    Period:number,
    Region:string,
    Vendor:string,
    SeriesCYColumnData:string,
    SeriesPYColumnData:string
}
export class AreaSplineObj {
    optionsBar={
    chart: {
        type: 'areaspline',
        height:40,
        margin:0,
        borderRadius: 0},
    title: {text: ''},
    exporting: {enabled: false},
    legend: {
      enabled:false,
      layout: 'vertical',
      align: 'left',
      verticalAlign: 'top',
      x: 150,
      y: 100,
      floating: false,
      borderWidth: 0,
      background:'transparent',
      backgroundColor:'transparent'
  },
  tooltip: {
      //enabled:false,
      shared: false
      //valueSuffix: ' units'
  },
  credits: {
      enabled: false
  },
  xAxis: {categories: []},
  plotOptions: {
      areaspline: {
        enabled: false,
        fillOpacity: 0.5, 
        lineOpacity:0.001,
        borderWidth: 0,
        showInLegend:false,
        marker:{
          enabled: false,
          border:0
        }
      },
  },
  series: [{
       lineWidth: 0,
       lineColor: 'transparent',
      data: [3, 4, 3, 10, 4, 10, 12]
  }]
}
}