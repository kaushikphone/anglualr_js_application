import { Component, OnInit, Compiler } from '@angular/core';
import {ApiService} from '../HttpService/ApiService';
import { ConfirmComponent } from '../confirm/confirm.component';
import { RightSimulation} from '../HttpService/menu';
import { DialogService } from 'ng2-bootstrap-modal';
import * as $ from 'jquery';
@Component({
  selector: 'pm-simulation',
  templateUrl: './simulation.component.html',
  styleUrls: [
    './simulation.component.css?v=${new Date().getTime()'
  ]
})
export class SimulationComponent implements OnInit {
  errorMessage: String;
  RightCardPopulate:RightSimulation[];
  constructor(
    private apiSerivce: ApiService,
    private _compiler: Compiler,
    private dialogService:DialogService
  ) { }

  ngOnInit() {
    this._compiler.clearCache();
    this.RightSimulationChartPopulate();
  }
  OpenCheckboxModal(){
    this.showConfirm();
}
  showConfirm(){
    let disposable = this.dialogService.addDialog(ConfirmComponent, {
        title:"Insights",
        message:'Insights'
      })
        .subscribe((isConfirmed)=>{
            if(isConfirmed) {
                //alert('accepted');
            }
            else {
                $('.checkboxDecliend').prop('checked', false); 
            }
        });
    setTimeout(()=>{
        //disposable.unsubscribe();
    },10000);
 }
  RightSimulationChartPopulate(){
    //debugger
    this.apiSerivce.getRightSideBar().subscribe(
      resultArray => this.RightCardPopulate = resultArray,
      error => this.errorMessage=<any> error
    )
  }

}
