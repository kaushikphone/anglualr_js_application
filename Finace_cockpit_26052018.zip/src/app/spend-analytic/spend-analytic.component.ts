import { Component, OnInit,ViewChild, AfterViewInit, Input, Output,Compiler, ElementRef } from '@angular/core';
import {ApiService} from '../HttpService/ApiService';
import { Menu, Card ,ComparativeAnalysis,getDisputedAmount, GetCharts_LTMUnmanSpendByBusEntity,GetCharts_LTMUnmanSpendByMatCatByPeriod, AreaSplineObj} from '../HttpService/menu';
import {FormsModule} from '@angular/forms';
import { environment } from "../../environments/environment";
import { AngularFontAwesomeModule } from 'angular-font-awesome';
import { Angular2Csv } from 'angular2-csv/Angular2-csv';
//import { ConfirmComponent } from '../confirm/confirm.component';
import { DialogService } from "ng2-bootstrap-modal";
//import { CardComponent } from '../card/card.component';
import { Chart } from 'angular-highcharts';
//import * as Highcharts from 'highcharts';
//import './test.js';
//import * as html2canvas from 'html2canvas/dist/html2canvas.js';
//import * as jsPDF from 'jspdf';
declare var require: any;
import { UrlReadJSON } from "../HttpService/urlRead";
//require('highcharts')(Highcharts);
var Highcharts = require('highcharts');
require('highcharts/highcharts-more')(Highcharts);
require('highcharts/modules/solid-gauge')(Highcharts);
require('highcharts/modules/heatmap')(Highcharts);
require('highcharts/modules/drilldown')(Highcharts);
require('highcharts-grouped-categories/grouped-categories')(Highcharts);
require('highcharts/modules/treemap')(Highcharts);
require('highcharts/modules/funnel')(Highcharts);
require('highcharts/modules/exporting')(Highcharts);
require('highcharts/modules/exporting.src')(Highcharts);
require('highcharts/modules/offline-exporting')(Highcharts);
//import { StockChart } from 'angular-highcharts';
import * as $ from 'jquery';
import { toTypeScript } from '@angular/compiler';
import { Static } from 'highcharts/highstock';
import { highchartsModules } from '../app.module';
import { error } from 'util';
import { Router } from '@angular/router';
import { ChartGraphBarDirective } from '../chart-graph-bar.directive';
import { ConfirmComponent } from '../confirm/confirm.component';
@Component({
  selector: 'pm-spend-analytic',
  templateUrl: './spend-analytic.component.html',
  styleUrls: [
      './spend-analytic.component.css?v=${new Date().getTime()',
      './cardView.css?v=${new Date().getTime()',
      './sidebar.css?v=${new Date().getTime()',
      './export.css?v=${new Date().getTime()',
      './icon.css?v=${new Date().getTime()',
      './print.css?v=${new Date().getTime()',
      './sidebarCollapse.css?v=${new Date().getTime()'
    ],
  providers:[ApiService,AreaSplineObj]
})

export class SpendAnalyticComponent implements OnInit  {
   parentMessage:Card[];
   _downloadExcel:string=(new UrlReadJSON()).optionsBar._downloadExcel;
  
   //@Input() childMessage: Card[];
   @ViewChild('ExporterElement') container: ElementRef;
   @ViewChild('bar') containerPlus:ElementRef;
   childMessage: Card[];
   extract_Comparative_Analysis:ComparativeAnalysis[];
   OptionVal:number;
   CardName:string[]=['Maverick spend','Dispute Invoice','Potential Savings','Suspicious Invoice']; 
   MaverickValue:string;
   PercentageValue:string;
   disputedValue:string;
   potentialSavings:string;
   MavericCardSplitValue:number[];
   SelectedOptionVal:number;
   DisputedAmount:number[];
   DisputePeriod:string[];
   disputedText:string;
   PeriodValue:string;
   extractAllData:any[];
   globalOption:number;
   year:number;
   entityid:number;
   vendorid:number;
   HighchartsB:Chart;
   chartWidth:500;
   chartHeight:250;
   _downExcelBar:string;
   _dynamicInsightBar:string;
   ColorArray=["#e0301e","#d93954","#602320","#d04a02","#817a64"];
  public chartOneHeading:string="Comparative Analysis - Managed vs Unmanaged  Spend - LTM";
  public chartSecondHeading:string="LTM Unmanaged Spend by Business Entitiy";
  public chartThirdHeading:string="LTM Unmanaged Spend by Vendor";
  public chartFourthHeading:string="LTM Unmanaged Spend by Material Category";
  months = [{'name': 'Feb','value':'1'}, {'name': 'March','value':'2'}];
  selectedMonth = this.months[1];
  errorMessage: String;
  _fetchCard: Card[];
  //message:string="vsl";
  ComparativeAnalysis:Chart;
  LTM_Unmanaged:Chart;
  LTM_Unmanaged_Material_Category:Chart;
  LTM_Unmanaged_Spend_by_Vendor:Chart;
  areaChartSpline:Chart;
  areaChartSplineMaverickSpend:Chart;
  areaChartSplineDispute:Chart;
  areaChartSplinePotentialSavings:Chart;
  areaChartSplineSuspecious:Chart;
  
  //stock: StockChart;
  constructor(
    private apiSerivce: ApiService,
    private _compiler: Compiler,
    private dialogService:DialogService,
    private _areaSplineMaveric:AreaSplineObj,
    private _areaSplineDisputeInvoice:AreaSplineObj,
    private _areaSplinePotentialSavings:AreaSplineObj,
    private _areaSplineSuspiciuosInvoice:AreaSplineObj,
    private router: Router,
    
  ) { 
  
  }
  ngOnInit() {
    this._compiler.clearCache();
    this.cardDataBinding();
    this.potentialSavings="1.5";
    this.ExportCSV();
    this.chartDataBinding(this.OptionVal);
    $('.overlay').on('click', function () {
        $('#sidebar').removeClass('active');
        $('.overlay').fadeOut();
        $('.lighterBar,.lighter').fadeOut();
        
    });
    
    console.log(Highcharts);
    /*let socket = socketIo("http://localhost:4200");
    socket.on('/api/menu/menu.json', function (data) {
        debugger
        console.log("Socket_data:"+data);
        socket.emit('my other event', { my: 'data' });
      });*/
  }
  ngAfterViewInit() {

  }
  formatterFunction(assignVal): string{
    var maxElement = assignVal;
    var u1 = 10000, u2 = 10000000, u3 = 10000000000;
    if (maxElement > u3) {
        return parseInt((assignVal / (u3/10)).toFixed(0)) +"B";
    } else if (maxElement > u2) {
        return parseInt((assignVal / (u2/10)).toFixed(0)) +"M";
    } else if (maxElement > u1) {
        return parseInt((assignVal / (u1/10)).toFixed(0)) +"k";
    }
    else{
        return parseInt(assignVal).toString()
    }
  }
  OuterClickDisable(){
    $(document).mouseup(function(e) 
{
    var container = $(".lighter,.lighterBar");
    if (!container.is(e.target) && container.has(e.target).length === 0) 
    {
        container.hide();
    }
});
  }
  HoverAnimateOpening(el){
    this.OuterClickDisable();
    $('.lighter').hide();
    $('#'+el).parents('.minEqualWidthContainer').find('.lighter').show();
  }
  LightChartClick(el){
    this.OuterClickDisable();
    $('.lighterBar').hide();
    $('#'+el).parents('.panel-body').find('.lighterBar').show().css({
        'left':'10px',
        'right':'0',
        'z-index':'24'
    });
  }
  icons(el){
    debugger
    this._dynamicInsightBar=el;
    $('#sidebar').toggleClass('active');
    $('.overlay').fadeIn();
  }
  //Menu bar opeing//
  
  cardDataBinding() {
    this.OptionVal=$("#MonthSelector").find("option:selected").val();
    this.year=new Date().getFullYear();
    this.entityid=-1;
    this.vendorid=-1;
    this.areaSplineBinding();
    this.apiSerivce.getCardViewList(this.OptionVal).subscribe(
      resultArray => this.childMessage = resultArray,
      error => this.errorMessage=<any> error
    )
  }
  //print and export pdf code
  windowPrint(el){
     let restorepage = $('body').html();
     let printcontent = $('#' + el);
    $('body').empty().html(printcontent);
    window.print();
    $('body').html(restorepage);
  }
  
  //Export Csv part
  ExportCSV(){
      debugger
      this.SelectedOptionVal=parseInt($("#MonthSelector").find("option:selected").val());
      this._downExcelBar=this._downloadExcel+"?year="+this.year+"&period="+this.SelectedOptionVal+"&entityId=0&VendorId=0";
      //this.router.navigate([this._downloadExcel+"?year="+this.year+"&period="+this.SelectedOptionVal+"&entityId=0&VendorId=0"]);
  }
  //modal service calculation
  ModalWindonOpening(){
      debugger
      //$("#bar").removeClass("hide");
      //this.containerPlus.nativeElement.removeClass('hide');
      (new ChartGraphBarDirective(this.dialogService)).showConfirm(
          this._dynamicInsightBar,
          this.MavericCardSplitValue,
          this.PeriodValue,
          this.DisputedAmount,
          this.DisputePeriod
        );
  }
  exportData(data){ 
    let blob = data;
    let a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = 'fileName.xls';
    document.body.appendChild(a);
    a.click();        
}
 //highchat function
 ExportAllCSV(ChartType){
     //debugger
     let chartArray=[this.ComparativeAnalysis];
     Highcharts.getCSV =function(charts){
      var svgArr = [],top = 0,width = 0;
      Highcharts.each(charts, function (chart1Bar) {
        var csv = chart1Bar.getCSV();
        svgArr.push(csv);
      })
     }
     Highcharts.exportCharts = function (charts, options) {
      options = Highcharts.merge(Highcharts.getOptions().exporting, options);
      Highcharts.post(options.url, {
          filename: options.filename || 'Spend Analytics',
          type: options.type,
          width: options.width,
          csv: Highcharts.getCSV(charts)
      });
  };
  Highcharts.exportCharts(chartArray, {
      type: ChartType
  });
    //new Angular2Csv(pushObj, 'My Report',options);
    
 }
 exportPdfController(ChartType,chartArray){
    Highcharts.getSVG = function (charts) {
        var svgArr = [],top = 0,width = 0;   
        Highcharts.each(charts, function (chart1Bar) {
            var svg = chart1Bar.ref.getSVG(),
                svgWidth = +svg.match(
                    /^<svg[^>]*width\s*=\s*\"?(\d+)\"?[^>]*>/
                )[1],
                svgHeight = +svg.match(
                    /^<svg[^>]*height\s*=\s*\"?(\d+)\"?[^>]*>/
                )[1];
            svg = svg.replace(
                '<svg',
                '<g transform="translate(0,' + top + ')" '
            );
            svg = svg.replace('</svg>', '</g>');
            top += svgHeight;
            width = Math.max(width, svgWidth);
            svgArr.push(svg);
        });
    
        return '<svg height="' + top + '" width="' + width +
            '" version="1.1" xmlns="http://www.w3.org/2000/svg">' +
            svgArr.join('') + '</svg>';
    };
    Highcharts.exportCharts = function (charts, options) {
        options = Highcharts.merge(Highcharts.getOptions().exporting, options);
        Highcharts.post(options.url, {
            filename: options.filename || 'Spend Analytics',
            type: options.type,
            width: options.width,
            svg: Highcharts.getSVG(charts)
        });
    };
    Highcharts.exportCharts(chartArray, {
        type: ChartType
    });
 }
 ExportAll(chartT){
     let ChartType=chartT;
     //console.log(ChartType);
     this.exportPdfController(ChartType,[this.ComparativeAnalysis,this.LTM_Unmanaged,this.LTM_Unmanaged_Spend_by_Vendor,this.LTM_Unmanaged_Material_Category]);
}
  OnMonthChange($event){
    this.OptionVal= $event.target.value;
    this.apiSerivce.getCardViewList(this.OptionVal).subscribe(
      resultArray => this.childMessage = resultArray,
      error => this.errorMessage=<any> error
    )
    this.chartDataBinding($event.target.value);
    this.ExportCSV();
    if(this.OptionVal==2)
      this.potentialSavings="1.8";
    else
      this.potentialSavings="1.5";
    //debugger
    this.onchangeAreaCardSpline();
    this.parentMessage=this.childMessage;
  }
  
  commaSeperatorNumber(strVale: string): number[]{
    var strArr = strVale.split(',');
    let intArr: number[]=[];
    for(let i=0; i < strArr.length; i++)
      intArr.push(parseFloat(strArr[i]));
    return intArr
  }
  onchangeAreaCardSpline(){
    //debugger
    this.apiSerivce.getDisputedAmount(this.OptionVal,this.year).subscribe(
      data=>{
        console.log("DisputedText:"+data);
        this.disputedValue=data["TotDisputedPercentage"]+"%, ";
        this.disputedText=this.formatterFunction(data["TotDisputedAmount"]);
        this.DisputedAmount = data["DisputedAmount"].split(",").reduce(function(prev, curr) {
          return prev.concat(parseFloat(curr));
      }, []);
      this.DisputePeriod=data["Period"].split(',');
      },
      error => this.errorMessage=<any> error
    )
  }
  areaSplineBinding(){
      this.onchangeAreaCardSpline();
      console.log("MavrickValue:"+this.MavericCardSplitValue);
      this.areaChartSplineMaverickSpend=new Chart((new AreaSplineObj()).optionsBar);
      this.areaChartSplineMaverickSpend.options.series[0].color=this.ColorArray[0];
      this.areaChartSplineMaverickSpend.options.series[0].data=this.MavericCardSplitValue;
      this.areaChartSplineMaverickSpend.options.xAxis["categories"]=this.PeriodValue;
      /*this.areaChartSplineMaverickSpend.options.tooltip.formatter=function():any{
        return '<b>dddd</b>'
      };*/
      this.areaChartSplineDispute=new Chart((new AreaSplineObj()).optionsBar);
      this.areaChartSplineDispute.options.series[0].color=this.ColorArray[1];
      this.areaChartSplineDispute.options.series[0].data=this.DisputedAmount;
      this.areaChartSplineDispute.options.xAxis["categories"]=this.DisputePeriod;
      
      this.areaChartSplinePotentialSavings=new Chart((new AreaSplineObj()).optionsBar);
      this.areaChartSplinePotentialSavings.options.series[0].color=this.ColorArray[2];
      this.areaChartSplinePotentialSavings.options.series[0].data=[3, 1, 3, 1, 8, 1, 4];
      this.areaChartSplineSuspecious=new Chart((new AreaSplineObj()).optionsBar);
      this.areaChartSplineSuspecious.options.series[0].color=this.ColorArray[3];
      this.areaChartSplineSuspecious.options.series[0].data=[1, 4, 1, 9, 1, 2, 8];
  }
  chartDataBinding(targetValue){
    let widthB=$(".heighChartContainerPane").width();
    let heightB=$(".heighChartContainerPane").height();
    
    this.apiSerivce._LTM_Unmanaged_Spend_Vendor_URL(this.OptionVal,this.year,this.vendorid).subscribe(
      data=>{
        //debugger
        console.log("LTM_Unmanaged_Spend_Vendor_URL:"+data);
        let categoriesArray=[];
        let Seriesname=['PY','CY'];
        let color=["#ffb300","#db6600"]
        let SeriesCYColumnData = data["SeriesCYColumnData"].split(",").reduce(function(prev, curr) {
            return prev.concat(parseFloat(curr));
        }, []);
        let SeriesPYColumnData = data["SeriesPYColumnData"].split(",").reduce(function(prev, curr) {
            return prev.concat(parseFloat(curr));
        }, []);
        let Regions = data["Region"].split(",");
        let RegionsDistinct =data["Region"].split(",").reduce(function(prev,curr){
            if(!prev.includes(curr))
               prev = prev.concat(curr);
            return prev;
        },[]);
        let vendorNames=data["Vendor"].split(",");
        for(var i=0; i<RegionsDistinct.length;i++){
            //debugger
            let pushVendors = [];
            for(var j=0;j<vendorNames.length;j++){
                if(Regions[j] == RegionsDistinct[i])
                {
                    pushVendors.push(vendorNames[j]);
                }
            }
            categoriesArray.push({
                "name":RegionsDistinct[i],
                "categories": pushVendors
            })
        }
        
        //let RegionsDistinct=data["Region"].split(",");
        let LTM_Unmanaged_Spend_by_Vendor_options={
          chart: {renderTo: "LTM_Unmanaged_Spend_by_Vendor",type: "column",width:550,height:250},
          credits: {enabled: false},
          exporting: {
              buttons:{
                contextButton: {
                    enabled: true
                },
                }
              },
          title: {useHTML: true,x: -10,y: 8,text: this.chartThirdHeading,style:{fontSize:"12px"}},
        series: [{
            name: 'PY',
            data: SeriesPYColumnData,
            color:"#ffb300"
        }, {
            name: 'CY',
            data: SeriesCYColumnData,
            color:"#db6600"
        }],
        xAxis: {
            categories: categoriesArray
        }
    }
    this.LTM_Unmanaged_Spend_by_Vendor=new Chart(LTM_Unmanaged_Spend_by_Vendor_options);
      },
      error => this.errorMessage=<any> error
    )
    this.apiSerivce.GetCharts_LTMUnmanSpendByMatCatByPeriod(this.OptionVal,this.year).subscribe(
      data=>{
        //let parseData=JSON.stringify(data);
       // let parseObj=JSON.parse(data).Materials;
        let dataPush=[];
        let MaterialName:string;
        let MaterialValue:number;
        let Firstmaterial={};
        let colorM=["#db6600","#ffb300","#5e2220","#ffb300","#ffb300","#aba698","#db6600"];
        let MaterialNames: string[];
        let MaterialValues: number[];
        let colorAxis={ maxColor:"#ffb300",minColor: '#db6600'}
       let points = [],
       materialP,
       materialVal,
       materialI = 0,
       regionP,
       regionI,
       vendorP,
       vendorI,
       material,
       region,
       vendor;
       
       data = JSON.parse(data).Materials;
   for (material in data) {
    var vendorPs=[];
       if (data.hasOwnProperty(material)) {
           materialVal = 0;
           materialP = {
               id: 'id_' + materialI,
               name: material,
               colorValue: 1
               //color:colorAxis.maxColor
           };
           regionI = 0;
           for (region in data[material]) {
               if (data[material].hasOwnProperty(region)) {
                   regionP = {
                       id: materialP.id + '_' + regionI,
                       name: region,
                       parent: materialP.id
                   };
                   points.push(regionP);
                   vendorI = 0;
                   for (vendor in data[material][region]) {
                       if (data[material][region].hasOwnProperty(vendor)) {
                           vendorP = {
                               id: regionP.id + '_' + vendorI,
                               name: vendor,
                               parent: regionP.id,
                               value: Math.round(+data[material][region][vendor]),
                               colorValue: Math.round(+data[material][region][vendor])
                           };
                           materialVal += vendorP.value;
                           vendorPs.push(vendorP);
                           //points.push(vendorP);
                           vendorI = vendorI + 1;
                       }
                   }
                   regionI = regionI + 1;
               }
           }
           materialP.value = Math.round(materialVal);
           materialP.colorValue=materialVal;
           points.push(materialP);
           debugger;
           let vp;
           for(let i=0; i< vendorPs.length; i++)
           {
             vp = vendorPs[i];
             vp.colorValue = materialVal;
             points.push(vp);
           }
           /*points.push({
             "name":materialP,
              "value":Math.round(materialVal),
              "colorValue":Math.round(materialVal)
            });*/
           materialI = materialI + 1;
       }
   }










       // console.log("dataPush:"+dataPush);
       // MaterialNames = data["MateriaNames"].split(",");
        //MaterialValues = data["MaterialValues"].split(",").reduce(function(prev, curr) {
          //return prev.concat(parseFloat(curr));
      //}, []);

        /*for(let i=0; i<MaterialNames.length; i++){
          dataPush.push(
            {
              "name":MaterialNames[i],
              "value":MaterialValues[i],
              //"color":color[i],
              "colorValue":MaterialValues[i]
          }
          )
        }*/
        let LTM_Unmanaged_Material_Category_options={
          chart: {renderTo: 'Unmanaged_material',width: 550,height: 250},
          title: {useHTML: true,x: -10,y: 8,text: this.chartFourthHeading,style:{fontSize:"12px"}},
          exporting: {enabled: false},
          credits: {enabled: false},
          colorAxis:{ maxColor:"#db6600",minColor: '#ffb300'},
          series: [{
            type: 'treemap',
            layoutAlgorithm: 'squarified',
            allowDrillToNode: true,
            levelIsConstant: false,
            animationLimit:1000,
            dataLabels: {
                enabled: false
            },
            levels: [{
                level: 1,
                dataLabels: {
                    enabled: true
                },
                borderWidth: 0,
                borderColor:"red"
            }],
            data: points
        }],
        }
        this.LTM_Unmanaged_Material_Category=new Chart(LTM_Unmanaged_Material_Category_options);
      }
    )
    this.apiSerivce.get_LTM_Unmanaged_Spend(this.OptionVal,this.year,this.entityid).subscribe(
        data=>{
          console.log("get_ltm_data"+data);
          //drill down option
          data = JSON.parse(data).Entities;
         var seriesData = [];
         var seriesDril = [];
         var splineArrData = [];
         var CYData = [], PYData = [];
        for (let entity in data) {
        var CYSeriesDataDril = [], PYSeriesDataDril = [];
        var cyVal = 0, pyVal = 0;
        var splineObj = <any>{}, varWithPY = 0.0;

        for (let region in data[entity]) {
            var cySeriesRegDril = [region, parseFloat(data[entity][region]['CY'])],
                pySeriesRegDril = [region, parseFloat(data[entity][region]['PY'])];

            cyVal += parseFloat(data[entity][region]['CY']);
            pyVal += parseFloat(data[entity][region]['PY']);

            CYSeriesDataDril.push(cySeriesRegDril);
            PYSeriesDataDril.push(pySeriesRegDril);

            varWithPY += parseFloat(data[entity][region]['VarWithPY']);
        }

        let cy = <any>{};
        CYData.push(cy);
        cy.name = entity;
        cy.y = cyVal;
        cy.drilldown = entity + '-CY';

        let py = <any>{};
        PYData.push(py)
        py.name = entity;
        py.y = pyVal;
        py.drilldown = entity + '-PY';

        let seriesDrilEntity = <any>{};
        seriesDrilEntity.type = 'column';
        seriesDrilEntity.id = entity + '-CY';
        seriesDrilEntity.data = CYSeriesDataDril;
        seriesDril.push(seriesDrilEntity);

        seriesDrilEntity = <any>{};
        seriesDrilEntity.type = 'column';
        seriesDrilEntity.id = entity + '-PY';
        seriesDrilEntity.data = PYSeriesDataDril;
        seriesDril.push(seriesDrilEntity);

        splineObj.name = entity;
        splineObj.y = varWithPY;
        splineArrData.push(splineObj);
    }

    seriesData.push({type: 'column',name: 'CY',data: CYData,color:"#db6600"});
    seriesData.push({type: 'column',name: 'PY',data: PYData,color: "#ffb300"});
    seriesData.push({type: 'spline',name: 'Variance with PY',yAxis: 1,data: splineArrData,color:"#e67010",
    marker: {
        lineWidth: 2,
        lineColor:"#ffb300",
        fillColor: 'white'
    }});
    let dril = <any>{};
    dril.series = seriesDril;
          console.log("Entity:"+data["Categories"]);
          let LTM_Unmanaged_options={
            chart: {renderTo: 'LTM_Unmanaged',width: 550,height: 250},
            exporting: {enabled: false},
            title: {useHTML: true,x: -10,y: 8,text: this.chartSecondHeading,style:{fontSize:"12px"}},
            legend: {align: 'left',verticalAlign: 'bottom',itemStyle: {color: 'black',fontWeight: 'normal',fontSize: '12px'}   
          },
          credits: {enabled: false},
          xAxis: {
            useHTML:true,
            type: 'category',
            labels: {
              formatter: function () {
                  if (this.value) {
                      return '<span style="fill: #666666; font-size:11px; display:inline-block; font-weight:normal; text-decoration:none">' + this.value + '</span>';
                  }
              }
          }
        },
          //xAxis: {categories: (data["Categories"]).split(',')},
          yAxis: [
            {
                title: {
                    text: 'Values'
                }
            },
            {
                title: {
                    text: 'Variance'
                },
                opposite: true
            }
        ],
          plotOptions: {
            series: {
                //stacking: 'normal',
                borderWidth: 0,
                dataLabels: {
                    enabled: false
                }
            }
        },

          labels: {
              items: [{
                  html: '',
                  style: {
                      left: '50px',
                      top: '18px',
                      color:"#db6600"
                  }
              }]
          },
          
          series: seriesData,
          drilldown: dril,
          /*series: [{
              type: 'column',
              name: 'PY',
              color: "#ffb300",
              //yAxis: 1,
              data: this.commaSeperatorNumber(data["PYColumnData"])
          }, {
              type: 'column',
              name: 'CY',
              color:"#db6600",
              //yAxis: 1,
              data: this.commaSeperatorNumber(data["CYColumnData"])
          }, {
              type: 'spline',
              name: 'Variance with PY',
              color:"#e67010",
              yAxis: 1,
              data: this.commaSeperatorNumber(data["VarWithPY"]),
              marker: {
                  lineWidth: 2,
                  lineColor:"#ffb300",
                  fillColor: 'white'
              }
          }]*/
          }
          this.LTM_Unmanaged=new Chart(LTM_Unmanaged_options);
          this.LTM_Unmanaged.options.xAxis["labels"].fill="red";
          
        },
        error => this.errorMessage=<any> error
    )
    this.apiSerivce.get_Comparative_Analysis(this.OptionVal,this.year).subscribe(
      data=>{
        console.log("Comparative_Valiue:"+data);
        //debugger
        this.extractAllData=data;
        this.MaverickValue=this.formatterFunction(data["CYUnmanagedCol"].split(/[, ]+/).pop());
        let UnmanagedValue=parseInt(data["CYUnmanagedCol"].split(/[, ]+/).pop());
        let ManagedValue=parseInt(data["CYManagedCol"].split(/[, ]+/).pop());
        let TotalValuewithUnmanaged=UnmanagedValue+ManagedValue;
        this.PercentageValue=(UnmanagedValue/TotalValuewithUnmanaged*100).toFixed(2)+"%";
        this.MavericCardSplitValue = data["CYUnmanagedCol"].split(",").reduce(function(prev, curr) {
            return prev.concat(parseFloat(curr));
        }, []);
        this.PeriodValue=data["Period"].split(',');
        this.areaSplineBinding();
        console.log("Period:"+data["Period"]);
        let CYUnmanagedColVals: number[] = this.commaSeperatorNumber(data["CYUnmanagedCol"]);
        let CYManagedColVals: number[]=this.commaSeperatorNumber(data["CYManagedCol"]);
        let VarWithPYUnmanagedVals: number[]=this.commaSeperatorNumber(data["VarWithPYUnmanaged"]);
        let ComparativeAnalysis_options={
          chart: {type: "column",width: 550,height: 250},
          title: {
              useHTML: true,
              x: -10,y: 8,
              text: this.chartOneHeading,
              style:{fontSize:"12px"},
              events: {click:function(){} 
          }},
          credits: {enabled: false},
          exporting:{enabled:false},
          legend: {align: 'left',verticalAlign: 'bottom',itemStyle: {color: 'black',fontWeight: 'normal',fontSize: '9px'}},
          xAxis: {categories: data["Period"].split(',')},
          yAxis: [
              {labels: {/*format: '{value} Mn',*/
              formatter: function () {
                //debugger
                var maxElement = this.axis.max;
                var u1 = 10000, u2 = 10000000, u3 = 10000000000;
                if (maxElement > u3) {
                    return parseInt((this.value / (u3/10)).toFixed(0)) + "B";
                } else if (maxElement > u2) {
                    return parseInt((this.value / (u2/10)).toFixed(0)) + "M";
                } else if (maxElement > u1) {
                    return parseInt((this.value / (u1/10)).toFixed(0)) + "k";
                }
                else {
                    return this.value;
                }
            },
              style: {color:"#ffb300"}},
              title: {text: 'Spend',style: {color:"#ffb300"}}
                  }, {title: {text: 'Variance',style: {color:"#db6600"}},
          labels: {format: '{value} %',style: {color:"#db6600"}}, 
          opposite: true,
    }],
    labels: {
      items: [{
          html: '',
          style: {
              left: '50px',
              top: '18px'
          }
      }]
    },
    plotOptions: {
      column: {
          stacking: 'normal'
      }
    },
    series: [{
      type: 'column',
      name: 'CY Unmanaged',
      color: "#ffb300",
      data:CYUnmanagedColVals
    }, {
      type: 'column',
      name: 'CY Managed',
      color:'#db6600',
      data:CYManagedColVals
    }, {
      type: 'spline',
      name: 'Variance with PY (Unmanaged)',
      yAxis: 1,
      color:"#e67010",
      //center: [300,-15],
      data:VarWithPYUnmanagedVals
    }, {
      type: 'pie',
      name: 'Total Spend',
      data: [{
          name: 'CY Unmanaged',
          y: parseFloat(data["PieTotSpendCYManaged"]),
          color: "#ffb300",
      }, {
          name: 'CY Managed',
          y: parseFloat(data["PieTotSpendCYUnmanaged"]),
          color:'#db6600',
      }],
      center: [300, 120],
      size: 30,
      showInLegend: false,
      dataLabels: {
          enabled: false
      }
    }]
        }        
        this.ComparativeAnalysis=new Chart(ComparativeAnalysis_options);
        
      },
      error => this.errorMessage=<any> error
    )
  }
}
