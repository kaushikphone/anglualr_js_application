import { ChartGraphBarDirective } from './chart-graph-bar.directive';

describe('ChartGraphBarDirective', () => {
  it('should create an instance', () => {
    const directive = new ChartGraphBarDirective();
    expect(directive).toBeTruthy();
  });
});
