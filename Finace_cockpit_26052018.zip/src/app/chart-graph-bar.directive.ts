import {Directive} from '@angular/core';
import { DialogService } from 'ng2-bootstrap-modal';
import { ConfirmComponent } from './confirm/confirm.component';
import * as $ from 'jquery';
@Directive({
  selector: '[pmChartGraphBar]'
})
export class ChartGraphBarDirective {
  
  optionsK:object;
  width: number;
  height: number;
  type: string;
  coloM: any = ["#ffb300", "#db6600", "#e67010"];
  constructor(
    private dialogService:DialogService
  ) {
    
  }
  ReuseTitle:object={
    useHTML: true,
    x: -10,
    y: 8,
    text: [],style: {fontSize: "12px"}            
  }
  legendobj:object={
    align: 'left',
    verticalAlign: 'bottom',
    itemStyle: {
        color: 'black',
        fontWeight: 'normal',
        fontSize: '9px'
    }
  }
  //optionsk = {chart: {type: this.type,width: this.width,height: this.height},title: this.ReuseTitle,legend: this.legendobj,xAxis: {categories: []}}

  //confirm dialog service
  showConfirm(title,MavericCardSplitValue,PeriodValue,DisputedAmount,DisputePeriod){
    let disposable = this.dialogService.addDialog(ConfirmComponent, {
        title:title,
        message:'Insights',
        MavericCardSplitValue:MavericCardSplitValue,
        PeriodValue:PeriodValue,
        DisputedAmount:DisputedAmount,
        DisputePeriod:DisputePeriod
      })
        .subscribe((isConfirmed)=>{
            if(isConfirmed) {                
            }
            else {
            }
        });
    setTimeout(()=>{
    },10000);
 }

}