var jsData;
var _reporturl = "https://15f0h4dk32.execute-api.us-east-1.amazonaws.com/KKR_DEV/report";
var _dataloadStatusUrl="https://15f0h4dk32.execute-api.us-east-1.amazonaws.com/KKR_DEV/dataloadstatus";
var d;
	$.getJSON(_reporturl,function (data) {
		d=data.d;
    console.log(d);
	  var columnNumber=[6,7,8,9,10,11,12,13,14,15,16,17];
    $('#kkrReport').DataTable({
    	"responsive":true,
    	"filter":true,
    	"orderable":true,
    	"binfo":false,
        "dom": 'Bfrtip',
        "scrollY":"60vh",
        "bScrollCollapse":true,
        "sScrollX":"100%",
        "buttons": ['csv', 'excel', {extend: 'pdfHtml5', orientation: 'landscape', pageSize: 'A2'}],
        "aaData":data,
				"aoColumnDefs": [
						{ "bVisible": true, "aTargets": [ 0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20 ] }
				],
        "columns":[
        	{"mDataProp":"legal_entity","title":"legal_entity"},
        	{"mDataProp":"deal_name","title":"deal_name"},
        	{"mDataProp":"issuer_name","title":"issuer_name"},
        	{"mDataProp":"position","title":"position"},
        	{"mDataProp":"fas_157_level","title":"fas_157_level"},
        	{"mDataProp":"asset_class","title":"asset_class"},
        	{"mDataProp":"geography","title":"geography"},
        	{"mDataProp":"industry","title":"industry"},
        	{"mDataProp":"active/inactive","title":"active/inactive"},
        	{"mDataProp":"holding_fund","title":"holding_fund"},
        	{"mDataProp":"cost_begin","title":"cost_begin"},
        	{"mDataProp":"cost_purchases","title":"cost_purchases"},
        	{"mDataProp":"cost_sales","title":"cost_sales"},
        	{"mDataProp":"cost_end","title":"cost_end"},
        	{"mDataProp":"fv_begin","title":"fv_begin"},
        	{"mDataProp":"fv_purchases","title":"fv_purchases"},
        	{"mDataProp":"fv_sales","title":"fv_sales"},
        	{"mDataProp":"change_in_value","title":"change_in_value"},
					{"mDataProp":"fv_end","title":"fv_end"},
					{"mDataProp":"realized_gl","title":"realized_gl"},
					{"mDataProp":"unrealized_gl","title":"unrealized_gl"}
        ],
        'columnDefs':[
        	{
        	'targets':columnNumber,
        	'className':'text-right',
        	'render' : $.fn.dataTable.render.number( ',', '.', 2 )
        	}
        ]
    });
	});
//Trigger button and open one report//
function OpenReport(){
  $.getJSON(_dataloadStatusUrl,function (data) {
    d=data.d;
    //dataload report data binding//
    $('#dataLoadStatus').DataTable({
          "responsive":true,
          "filter":true,
          "orderable":true,
          "binfo":false,
          "dom": 'Bfrtip',
          "scrollY":"60vh",
          "bScrollCollapse":true,
          "sScrollX":"100%",
          "aaData":data,
          "columns":[
        	{"mDataProp":"file_name","title":"file_name"},
        	{"mDataProp":"load_time","title":"load_time"},
        	{"mDataProp":"year","title":"year"},
          {"mDataProp":"quarter","title":"quarter"},
          {"mDataProp":"number_of_records","title":"number_of_records"}
        ],
    });
    $('#dataLoadStatus').DataTable().destroy();
    //dataload report data binding//
  });
  $('#reportModal').modal('show');
}
//Trigger button and open one report//
