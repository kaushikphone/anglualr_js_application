document.addEventListener("DOMContentLoaded",event=>{
    //Initi firbase in application
    const app=firebase.app();
    console.log(app);
    const db =firebase.firestore();
    console.log(db);
    const getCustomerData =db.collection('data').doc('rBvg0qvfRJ0j9fOtZiN0');
    //fetch customer data manually
    //getCustomerData.get().then(doc=>{const data=doc.data();console.log(data)}).catch(console.log());               
    //fetch customer data snapshot
    //Risk and Independece team
    
    getCustomerData.onSnapshot(doc=>{
        debugger
        const data=doc.data();
        console.log(data);
        $("#NewAppend").empty();
        for(var i=0; i<data.data.length; i++){
            $("#NewAppend").append("<tr><td>"+data.data[i].name+"</td><td>"+data.data[i].office+"</td><td>"+data.data[i].profession+"</td><td><button class='btn btn-danger'>Update</button></td></tr>");
        }
    })
});
//Authentication login
function googleLogin(){
    const provider= new firebase.auth.GoogleAuthProvider();
    firebase.auth().signInWithPopup(provider)
            .then(result=>{
                const user =result.user;
                document.getElementById("userName").innerHTML="Hello"+user.email;
                document.getElementById("authProvider").style.display="none";
                console.log(user);
            })
            .catch(console.log)
}
//upload files to storage
function uploadFile(files){
    debugger
    console.log(files)
    const storageRef=firebase.storage().ref()
    console.log(storageRef)
    const filesRef =storageRef.child(files[0].name)
    const file =files.item(0)
    const task =filesRef.put(file)
    task.then(snapshot=>{
        console.log(snapshot)
        const url =snapshot.downloadURL
        $("#imgUpload").attr('src',url)
    })
    task.catch(console.log)
    
}
