export interface Menu{
    menuId: string;
    menuImage: string;
    menuName: string;
    pageName:string;
    isEnable:boolean;
}
export interface Card{
    CardID:number;
    Year:number;
    Period:number;
    CardName:string;
    CardIcon:string;
    GraphPath:string;
}

export interface RightSimulation{
    menuId:number;
    menuImage:string;
    simulationStateIncrease:string;
    simulationStateDecrease:string;
    isEnable:boolean
}
export interface ComparativeAnalysis{
    Charts_CompAnaManVsUnmanSpendID:number;
    Year:number;
    Period:number;
    CYUnmanagedCol:string;
    CYManagedCol:string;
    VarWithPYUnmanaged:string;
    PieTotSpendCYUnmanaged:string;
    PieTotSpendCYManaged:string;
}
export interface GetCharts_LTMUnmanSpendByBusEntity{
    Charts_LTMUnmanSpendByBusEntityID:number;
    Year:number;
    Period:number;
    Categories:string;
    PYColumnData:string;
    CYColumnData:string;
    VarWithPY:string;
    PieTotSpendCY:string;
    PieTotSpendPY:string;
}
export interface GetCharts_LTMUnmanSpendByMatCatByPeriod{
    Charts_LTMUnmanSpendByMatCatID:number;
    Year:number;
    Period:number;
    MateriaNames:string;
    MaterialValues:string;
    Materials:object;

}
export interface _LTM_Unmanaged_Spend_Vendor{
    year:number,
    Period:number,
    Region:string,
    Vendor:string,
    SeriesCYColumnData:string,
    SeriesPYColumnData:string
}