import {Injectable,ViewContainerRef} from "@angular/core";
import {Http, Response, Headers,RequestOptions, RequestMethod} from "@angular/http";
import { HttpClient } from '@angular/common/http';
import {Observable} from "rxjs/Observable";
import { ToastsManager } from 'ng2-toastr/ng2-toastr';
import "rxjs/Rx";
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/toPromise';
import {Menu, Card ,RightSimulation, ComparativeAnalysis, GetCharts_LTMUnmanSpendByBusEntity,GetCharts_LTMUnmanSpendByMatCatByPeriod,_LTM_Unmanaged_Spend_Vendor} from "./menu";
import { Ng4LoadingSpinnerService } from "ng4-loading-spinner";
declare var require: any;
@Injectable()
    export class ApiService{
        //config = require('./config.json');
        //baseURL:string=this.config.baseURL;
        baseURL:string="http://10.31.101.78:7001";
        private _menuURL=this.baseURL+"/Api/common/getleftmenu";
        private _RightSimulationUrl=this.baseURL+"/Api/common/getrightmenu";
        private _ComparativeAnalysisURL=this.baseURL+"/api/Chart/GetCompAnaManVsUnmanSpend";
        private _LTM_UnmanagedURL=this.baseURL+"/api/Chart/GetLTMUnmanSpendByEntity";
        private _LTM_Unmanaged_Spend_VendorURL=this.baseURL+"/api/Chart/GetLTMUnmanSpendByVendor";
        private _LTM_Unmanaged_Spend_Material_CategoryURL=this.baseURL+"/api/Chart/GetLTMUnmanSpendByMatCat";
        constructor(
            private _http: Http,
            private spinnerService: Ng4LoadingSpinnerService,
            public toastr: ToastsManager,
            vcr: ViewContainerRef
        ) {
            this.toastr.setRootViewContainerRef(vcr);
        }
        //loading spinner
        startLoadingSpinner() {
            this.spinnerService.show();
            setTimeout(function() {
              this.spinnerService.hide();
            }.bind(this), 3000);
          }
        //Menu data binding from dataBase//
        getMenuList():Observable<Menu[]>{
            this.startLoadingSpinner()
            return this._http.get(this._menuURL).map(this.extractMenuData).catch(this.handleError);
        }
        private extractMenuData(response: Response){
            let body=<Menu[]>response.json();
            console.log(body);
            return body ||[];
        } 
        //card view binding from web api//
        getCardViewList(OptionVal):Observable<Card[]>{
            this.startLoadingSpinner();
            return this._http.get(this.baseURL+"/Api/common/getcardsbyperiod?period="+OptionVal).map(this.extractCardData).catch(this.handleError);
        }
        private extractCardData(response: Response){
            let cardData=<Card[]>response.json();
            console.log(cardData);
            return cardData ||[];
        }
        //SideBar binding from local json
        getRightSideBar():Observable<RightSimulation[]>{ 
            this.startLoadingSpinner();
            return this._http.get(this._RightSimulationUrl).map(this.extractSimulation).catch(this.handleError);
        }
        private extractSimulation(response: Response){
            let SimulationData=<RightSimulation[]>response.json();
            console.log(SimulationData);
            return SimulationData ||[];
        }
        //Comparative Analysis chart data binding
        get_Comparative_Analysis(OptionVal,year):Observable<ComparativeAnalysis[]>{
            this.startLoadingSpinner();
            return this._http.get(this._ComparativeAnalysisURL+"?period="+OptionVal+"&year="+year).map(this.extractChartData).catch(this.handleError);
        }
        //LTM Unmanaged Spend chart data binding
        get_LTM_Unmanaged_Spend(OptionVal,year,entityid):Observable<GetCharts_LTMUnmanSpendByBusEntity[]>{
            this.startLoadingSpinner(); 
            return this._http.get(this._LTM_UnmanagedURL+"?period="+OptionVal+"&year="+year+"&entityid="+entityid).map(this._LTM_Unmanaged_Spend).catch(this.handleError);
        }
        //_LTM_Unmanaged_Spend_Vendor_URL chart data binding
        _LTM_Unmanaged_Spend_Vendor_URL(OptionVal,year,vendorid):Observable<_LTM_Unmanaged_Spend_Vendor[]>{
                this.startLoadingSpinner();
                return this._http.get(this._LTM_Unmanaged_Spend_VendorURL+"?period="+OptionVal+"&year="+year+"&vendorid="+vendorid).map(this._LTM_Unmanaged_Spend_Vendor_chart).catch(this.handleError);
        }
        private _LTM_Unmanaged_Spend_Vendor_chart(response:Response){
            let chart__LTM_Unmanaged_Spend_Vendor_chart=<_LTM_Unmanaged_Spend_Vendor[]>response.json();
            console.log(chart__LTM_Unmanaged_Spend_Vendor_chart);
            return chart__LTM_Unmanaged_Spend_Vendor_chart ||[];
        }
        //GetCharts_LTMUnmanSpendByMatCatByPeriod chart data binding
        GetCharts_LTMUnmanSpendByMatCatByPeriod(OptionVal,year){
            return this._http.get(this._LTM_Unmanaged_Spend_Material_CategoryURL+"?period="+OptionVal+"&year="+year).map(this._GetCharts_LTMUnmanSpendByMatCatByPeriod).catch(this.handleError);
        }
        private _GetCharts_LTMUnmanSpendByMatCatByPeriod(response:Response){
            let charts_LTMUnmanSpendByMatCatByPeriod=response.json();
            console.log(charts_LTMUnmanSpendByMatCatByPeriod);
            return charts_LTMUnmanSpendByMatCatByPeriod ||[];
        }
        private _LTM_Unmanaged_Spend(response:Response){
            let _LTM_Unmanaged_Spend_Data=<GetCharts_LTMUnmanSpendByBusEntity[]>response.json();
            console.log(_LTM_Unmanaged_Spend_Data);
            return _LTM_Unmanaged_Spend_Data ||[];
        }
        private extractChartData(response:Response){
            let ChartData=<ComparativeAnalysis[]>response.json();
            console.log(ChartData);
            return ChartData||[];
        }
        private handleError(error: Response) {
             //this.toastr.warning(error.statusText,"warning");
            return Observable.throw(error.statusText);
        }
            private handleErrorPromise (error: Response | any) {
                console.error(error.message || error);
                this.toastr.warning(error.message || error,"warning");
                return Promise.reject(error.message || error);
                }
        
    }

