
export interface product{
    MonthName: string;
    MonthDescription: string;
    Type: string,
    Date:string,
    status:string
}
 
