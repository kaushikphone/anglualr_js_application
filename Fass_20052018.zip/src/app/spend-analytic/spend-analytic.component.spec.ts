import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SpendAnalyticComponent } from './spend-analytic.component';

describe('SpendAnalyticComponent', () => {
  let component: SpendAnalyticComponent;
  let fixture: ComponentFixture<SpendAnalyticComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SpendAnalyticComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SpendAnalyticComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
