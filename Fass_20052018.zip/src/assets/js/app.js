/*$(document).ready(function() {
    alert();
    //setTimeout(function(){
    //Comparative_Analysis();
    //LTM_Unmanaged();
    //Unmanaged_material();
    //LTM_Unmanaged_Spend_by_Vendor();
      //},3000);
    
});*/

Highcharts.getSVG = function(charts, options, callback) {
    var svgArr = [],
    		top = 0,
        width = 0,
        i,
        svgResult = function (svgres) {
            var svg = svgres.replace('<svg', '<g transform="translate(0,' + top + ')" ');
            svg = svg.replace('</svg>', '</g>');
            top += charts[i].chartHeight;
            width = Math.max(width, charts[i].chartWidth);
            svgArr.push(svg);
            if (svgArr.length === charts.length) {
              callback('<svg height="'+ top +'" width="' + width + '" version="1.1" xmlns="http://www.w3.org/2000/svg">' + svgArr.join('') + '</svg>');
            }
        };
		for (i = 0; i < charts.length; ++i) {
				charts[i].getSVGForLocalExport(options, {}, function () { 
        	console.log("Failed to get SVG");
       	}, svgResult);
		}
};

/**
 * Create a global exportCharts method that takes an array of charts as an argument,
 * and exporting options as the second argument
 */
Highcharts.exportCharts = function(charts, options) {
		// Merge the options
    options = Highcharts.merge(Highcharts.getOptions().exporting, options);    
		
    var imageType = options && options.type || 'image/png';
  
		// Get SVG asynchronously and then download the resulting SVG
    Highcharts.getSVG(charts, options, function (svg) {
      Highcharts.downloadSVGLocal(svg,
        (options.filename || 'chart')  + '.' + (imageType === 'image/svg+xml' ? 'svg' : imageType.split('/')[1]),
        imageType,
        options.scale || 2,
        function () {
          console.log("Failed to export on client side");
        });
    });
};

function exporter(){
    alert("ss");
    Highcharts.exportCharts([areaChartSpline]);
};




function Comparative_Analysis() {
    var chartingOptions = {
        chart: {
            renderTo: 'Comparative_Analysis',
            width: 445,
            height: 200
        },
        legend: {
            align: 'left',
            verticalAlign: 'bottom',
            itemStyle: {
                color: 'black',
                fontWeight: 'normal',
                fontSize: '9px'
            }
        },
        title: {
            text: ''
        },
        exporting: {
            enabled: false
        },
        xAxis: {
            categories: ['Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec', 'Jan', 'Feb', 'Mar']
        },
        yAxis: [{
            labels: {
                format: '{value} Mn',
                style: {
                    color:"#ffb300"
                    //color: Highcharts.getOptions().colors[1]
                }
            },
            title: {
                text: 'Spend',
                style: {
                    color:"#ffb300"
                    //color: Highcharts.getOptions().colors[1]
                }
            }
        }, {
            title: {
                text: 'Variance',
                style: {
                    color:"#db6600"
                    //color: Highcharts.getOptions().colors[0]
                }
            },
            labels: {
                format: '{value} %',
                style: {
                    color:"#db6600"
                    //color: Highcharts.getOptions().colors[0]
                }
            },
            opposite: true
        }],

        labels: {
            items: [{
                html: '',
                style: {
                    left: '50px',
                    top: '18px',
                    color: (Highcharts.theme && Highcharts.theme.textColor) || 'black'
                }
            }]
        },
        plotOptions: {
            column: {
                stacking: 'normal'
            }
        },
        credits: {
            enabled: false
        },
        series: [{
            type: 'column',
            name: 'CY Unmanaged',
            color: "#ffb300",
            //yAxis: 1,
            data: [0.60, 0.45, 1.55, 0.35, 0.30, 0.35, 0.20, 0.22, 0.35, 0.35, 0.40, 0.45]
        }, {
            type: 'column',
            name: 'CY Managed',
            color:'#db6600',
            //yAxis: 1,
            data: [1.10, 1.12, 0.25, 1.16, 1.50, 1.45, 1.37, 1.16, 1.02, 1.45, 1.16, 1.01]
        }, {
            type: 'spline',
            name: 'Variance with PY (Unmanaged)',
            yAxis: 1,
            color:"#e67010",
            data: [71, 80, 19, 56, 36, 75, 135, 83, 94, 75, 90, 125],
            marker: {
                lineWidth: 2,
                lineColor: Highcharts.getOptions().colors[3],
                fillColor: 'white'
            }
        }, {
            type: 'pie',
            name: 'Total Spend',
            data: [{
                name: 'CY Unmanaged',
                y: 5.75,
                color: "#ffb300",
                //color: Highcharts.getOptions().colors[1] // John's color
            }, {
                name: 'CY Managed',
                y: 13.75,
                color:'#db6600',
                //color: Highcharts.getOptions().colors[0] // Jane's color
            }],
            center: [300, -15],
            size: 30,
            showInLegend: false,
            dataLabels: {
                enabled: false
            }
        }]
    };
    chart = new Highcharts.Chart(chartingOptions);
}

function LTM_Unmanaged() {
    var chartingOptions = {
        chart: {
            renderTo: 'LTM_Unmanaged',
            width: 445,
            height: 200
        },
        exporting: {
            enabled: false
        },
        legend: {
            align: 'left',
            verticalAlign: 'bottom',
            itemStyle: {
                color: 'black',
                fontWeight: 'normal',
                fontSize: '12px'
            }
        },
        credits: {
            enabled: false
        },
        title: {
            text: ''
        },
        xAxis: {
            categories: ['Entity 1', 'Entity 2', 'Entity 3', 'Entity 4', 'Entity 5', 'Entity 6']
        },
        yAxis: [{ // Primary yAxis
            labels: {
                format: '{value} Mn',
                style: {
                    color:"#ffb300"
                    //color: Highcharts.getOptions().colors[1]
                }
            },
            title: {
                text: 'Spend',
                style: {
                    color:"#ffb300"
                    //color: Highcharts.getOptions().colors[1]
                }
            }
        }, { // Secondary yAxis
            title: {
                text: 'Variance',
                style: {
                    color:"#db6600"
                    //color: Highcharts.getOptions().colors[0]
                }
            },
            labels: {
                format: '{value} %',
                style: {
                    color:"#db6600"
                    //color: Highcharts.getOptions().colors[0]
                }
            },
            opposite: true
        }],

        labels: {
            items: [{
                html: '',
                style: {
                    left: '50px',
                    top: '18px',
                    color: (Highcharts.theme && Highcharts.theme.textColor) || 'black'
                }
            }]
        },

        series: [{
            type: 'column',
            name: 'PY',
            color: "#ffb300",
            //yAxis: 1,
            data: [2, 4, 3, 6, 4, 7]
        }, {
            type: 'column',
            name: 'CY',
            color:"#db6600",
            //yAxis: 1,
            data: [4, 6, 8, 5, 9, 2]
        }, {
            type: 'spline',
            name: 'Variance with PY',
            color:"#e67010",
            yAxis: 1,
            data: [34, 67, 45, 89, 34, 56],
            marker: {
                lineWidth: 2,
                lineColor: Highcharts.getOptions().colors[3],
                fillColor: 'white'
            }
        }, {
            type: 'pie',
            name: 'Total Spend',
            data: [{
                name: 'CY',
                y: 4.76,
                color: "#ffb300",
                //color: Highcharts.getOptions().colors[1]
            }, {
                name: 'PY',
                y: 11.25,
                color:'#db6600',
                //color: Highcharts.getOptions().colors[0]
            }],
            center: [300, -15],
            size: 30,
            showInLegend: false,
            dataLabels: {
                enabled: false
            }
        }]
    };
    chart = new Highcharts.Chart(chartingOptions);
}

function Unmanaged_material() {
    var chartingOptions = {
        chart: {
            renderTo: 'Unmanaged_material',
            width: 445,
            height: 200
        },
        exporting: {
            enabled: false
        },
        credits: {
            enabled: false
        },
        colorAxis: {
            maxColor:"#aba698",
            minColor: '#FFFFFF'
            //minColor: Highcharts.getOptions().colors[0],
            //maxColor: Highcharts.getOptions().colors[2]
        },
        series: [{
            type: 'treemap',
            layoutAlgorithm: 'squarified',
            data: [{
                name: 'Mat A',
                value: 1.948,
                color:"#db6600"
                //colorValue: 1.948
            }, {
                name: 'Mat B',
                value: 1.391,
                color:"#ffb300"
                //colorValue: 1.391
            }, {
                name: 'Mat C',
                value: 0.139,
                color:"#5e2220"
                //colorValue: 0.139
            }, {
                name: 'Mat D',
                value: 0.389,
                color:"#ffb300"
                //colorValue: 0.389
            }, {
                name: 'Mat E',
                value: 0.835,
                color:"#ffb300"
                //colorValue: 0.835
            }, {
                name: 'Mat F',
                value: 0.556,
                color:"#aba698"
                //colorValue: 0.556
            }, {
                name: 'Mat G',
                value: 0.278,
                color:"#db6600"
                //colorValue: 0.278
            }]
        }],
        title: {
            text: ''
        }
    }
    chart = new Highcharts.Chart(chartingOptions);
}

function LTM_Unmanaged_Spend_by_Vendor() {
    var chartingOptions = {
        chart: {
            renderTo: "LTM_Unmanaged_Spend_by_Vendor",
            type: "column",
            width:445,
            height:200
        },
        credits: {
            enabled: false
        },
        exporting: {
            enabled: false
        },
        title: {
            useHTML: true,
            x: -10,
            y: 8,
            text: ''
        },
        series: [{
            name: 'PY',
            data: [5, 3, 4, 7, 2, 5],
            color:"#ffb300"
            //stack: 'male'
        }, {
            name: 'CY',
            data: [6, 4, 4, 2, 5, 7],
            color:"#db6600"
            //stack: 'male'
        }],
        xAxis: {
            categories: [{
                name: "West -HQ",
                categories: ["V2", "V6"]
            }, {
                name: "North",
                categories: ["V1", "V3", "V4"]
            }, {
                name: "South",
                categories: ["V5"]
            }]
        }
    }
    chart = new Highcharts.Chart(chartingOptions);
}