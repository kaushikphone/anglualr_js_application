
export interface workspaceSummary{
    PreviewSummary:string;
    workspaceTile:string;
    MonthName: string;
    MonthDescription: string;
    Type: string,
    Date:string,
    status:string
}