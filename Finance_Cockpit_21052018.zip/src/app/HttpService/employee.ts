export interface Employee{
    firstname: string;
    lastname: string;
    email: string;
    designation: string;
    phonenumber:string;
}