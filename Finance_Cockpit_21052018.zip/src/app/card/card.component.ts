import { Component, OnInit, Input, Output,EventEmitter } from '@angular/core';
import {ApiService} from '../HttpService/ApiService';
import { Card } from '../HttpService/menu';
import * as $ from 'jquery';
import { toTypeScript } from '@angular/compiler';
@Component({
  selector: 'pm-card',
  templateUrl: './card.component.html',
  styleUrls: ['./card.component.css'],
  providers:[ApiService]
})
export class CardComponent implements OnInit {
  //parentMessage: Card[];
  @Input() childMessage: Card[];
  //@Output() OnMonthChange = new EventEmitter<Card[]>();
  errorMessage: String;
  constructor(
    private apiSerivce: ApiService
  ) { }

  ngOnInit() {
    this.cardDataBinding();
  }
  cardDataBinding() {
    let OptionVal=$("#MonthSelector").find("option:selected").val();
    this.apiSerivce.getCardViewList(OptionVal).subscribe(
      resultArray => this.childMessage = resultArray,
      error => this.errorMessage=<any> error
    )
    //this.parentMessage=this.childMessage;
    //this.OnMonthChange.emit(this.childMessage)
    //console.log(this._fetchCard);
  }

}
