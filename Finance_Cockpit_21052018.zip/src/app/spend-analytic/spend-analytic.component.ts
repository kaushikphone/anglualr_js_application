import { Component, OnInit,ViewChild, AfterViewInit, Input, Output,Compiler, ElementRef } from '@angular/core';
import {ApiService} from '../HttpService/ApiService';
import { Menu, Card ,ComparativeAnalysis, GetCharts_LTMUnmanSpendByBusEntity,GetCharts_LTMUnmanSpendByMatCatByPeriod} from '../HttpService/menu';
import {FormsModule} from '@angular/forms';
import { environment } from "../../environments/environment";
import { AngularFontAwesomeModule } from 'angular-font-awesome';
//import { ConfirmComponent } from '../confirm/confirm.component';
import { DialogService } from "ng2-bootstrap-modal";
//import { CardComponent } from '../card/card.component';
import { Chart } from 'angular-highcharts';
//import * as Highcharts from 'highcharts';
//import './test.js';
//import * as html2canvas from 'html2canvas/dist/html2canvas.js';
//import * as jsPDF from 'jspdf';
declare var require: any;
//require('highcharts')(Highcharts);
var Highcharts = require('highcharts');
require('highcharts/highcharts-more')(Highcharts);
require('highcharts/modules/solid-gauge')(Highcharts);
require('highcharts/modules/heatmap')(Highcharts);
require('highcharts-grouped-categories/grouped-categories')(Highcharts);
require('highcharts/modules/treemap')(Highcharts);
require('highcharts/modules/funnel')(Highcharts);
require('highcharts/modules/exporting')(Highcharts);
require('highcharts/modules/exporting.src')(Highcharts);
require('highcharts/modules/offline-exporting')(Highcharts);
//import { StockChart } from 'angular-highcharts';
import * as $ from 'jquery';
import { toTypeScript } from '@angular/compiler';
import { Static } from 'highcharts/highstock';
import { highchartsModules } from '../app.module';
@Component({
  selector: 'pm-spend-analytic',
  templateUrl: './spend-analytic.component.html',
  styleUrls: [
      './spend-analytic.component.css?v=${new Date().getTime()',
      './cardView.css?v=${new Date().getTime()',
      './sidebar.css?v=${new Date().getTime()',
      './export.css?v=${new Date().getTime()',
      './icon.css?v=${new Date().getTime()',
      './print.css?v=${new Date().getTime()',
      './sidebarCollapse.css?v=${new Date().getTime()'
    ],
  providers:[ApiService]
})
export class SpendAnalyticComponent implements OnInit  {
   parentMessage:Card[];
   //@Input() childMessage: Card[];
   @ViewChild('ExporterElement') container: ElementRef;
   childMessage: Card[];
   extract_Comparative_Analysis:ComparativeAnalysis[];
   OptionVal:number;
   year:number;
   entityid:number;
   vendorid:number;
   HighchartsB:Chart;
   chartWidth:500;
   chartHeight:250;
  public chartOneHeading:string="Comparative Analysis - Managed vs Unmanaged  Spend - LTM";
  public chartSecondHeading:string="LTM Unmanaged Spend by Business Entitiy";
  public chartThirdHeading:string="LTM Unmanaged Spend by Vendor";
  public chartFourthHeading:string="LTM Unmanaged Spend by Material Category";
  months = [{'name': 'Feb','value':'1'}, {'name': 'March','value':'2'}];
  selectedMonth = this.months[1];
  errorMessage: String;
  _fetchCard: Card[];
  //message:string="vsl";
  ComparativeAnalysis:Chart;
  LTM_Unmanaged:Chart;
  LTM_Unmanaged_Material_Category:Chart;
  LTM_Unmanaged_Spend_by_Vendor:Chart;
  areaChartSpline:Chart;
  
  //stock: StockChart;
  constructor(
    private apiSerivce: ApiService,
    private _compiler: Compiler,
    private dialogService:DialogService
  ) { 
   /*var testScript = document.createElement("script");  
    testScript.setAttribute("src", "/assets/js/jquery-3.3.1.min.js");
    testScript.setAttribute("src", "/assets/js/highcharts.js");
    testScript.setAttribute("src", "/assets/js/exporting.js");
    testScript.setAttribute("src", "/assets/js/export-data.js");
    testScript.setAttribute("src", "/assets/js/heatmap.js");
    testScript.setAttribute("src", "/assets/js/treemap.js");
    testScript.setAttribute("src", "/assets/js/app.js"); 
    document.body.appendChild(testScript);*/
  }

  ngOnInit() {
    this._compiler.clearCache();
    this.cardDataBinding();
    this.chartDataBinding(this.OptionVal);
    $('.overlay').on('click', function () {
        $('#sidebar').removeClass('active');
        $('.overlay').fadeOut();
    });
    console.log(Highcharts);
    /*let socket = socketIo("http://localhost:4200");
    socket.on('/api/menu/menu.json', function (data) {
        debugger
        console.log("Socket_data:"+data);
        socket.emit('my other event', { my: 'data' });
      });*/
  }
  ngAfterViewInit() {
  }
  HoverAnimateOpening(el){
    $('.lighter').hide();
    $('#'+el).parents('.minEqualWidthContainer').find('.lighter').show();
  }
  
  icons(){
    $('#sidebar').toggleClass('active');
    $('.overlay').fadeIn();
  }
  cardDataBinding() {
    this.OptionVal=$("#MonthSelector").find("option:selected").val();
    this.year=new Date().getFullYear();
    this.entityid=-1;
    this.vendorid=-1;
    this.apiSerivce.getCardViewList(this.OptionVal).subscribe(
      resultArray => this.childMessage = resultArray,
      error => this.errorMessage=<any> error
    )
  }
  //print and export pdf code
  windowPrint(el){
     let restorepage = $('body').html();
     let printcontent = $('#' + el);
    $('body').empty().html(printcontent);
    window.print();
    $('body').html(restorepage);
  }
  
 //highchat function
 exportPdfController(ChartType,chartArray){
    Highcharts.getSVG = function (charts) {
        var svgArr = [],top = 0,width = 0;   
        Highcharts.each(charts, function (chart1Bar) {
            var svg = chart1Bar.ref.getSVG(),
                svgWidth = +svg.match(
                    /^<svg[^>]*width\s*=\s*\"?(\d+)\"?[^>]*>/
                )[1],
                svgHeight = +svg.match(
                    /^<svg[^>]*height\s*=\s*\"?(\d+)\"?[^>]*>/
                )[1];
            svg = svg.replace(
                '<svg',
                '<g transform="translate(0,' + top + ')" '
            );
            svg = svg.replace('</svg>', '</g>');
            top += svgHeight;
            width = Math.max(width, svgWidth);
            svgArr.push(svg);
        });
    
        return '<svg height="' + top + '" width="' + width +
            '" version="1.1" xmlns="http://www.w3.org/2000/svg">' +
            svgArr.join('') + '</svg>';
    };
    Highcharts.exportCharts = function (charts, options) {
        options = Highcharts.merge(Highcharts.getOptions().exporting, options);
        Highcharts.post(options.url, {
            filename: options.filename || 'Spend Analytics',
            type: options.type,
            width: options.width,
            svg: Highcharts.getSVG(charts)
        });
    };
    Highcharts.exportCharts(chartArray, {
        type: ChartType
    });
 }
 ExportAll(chartT){
     let ChartType=chartT;
     //console.log(ChartType);
     this.exportPdfController(ChartType,[this.ComparativeAnalysis,this.LTM_Unmanaged,this.LTM_Unmanaged_Spend_by_Vendor,this.LTM_Unmanaged_Material_Category]);
}
  OnMonthChange($event){
    this.OptionVal= $event.target.value;
    this.apiSerivce.getCardViewList(this.OptionVal).subscribe(
      resultArray => this.childMessage = resultArray,
      error => this.errorMessage=<any> error
    )
    this.chartDataBinding($event.target.value)
    this.parentMessage=this.childMessage;
  }
  
  commaSeperatorNumber(strVale: string): number[]{
    var strArr = strVale.split(',');
    let intArr: number[]=[];
    for(let i=0; i < strArr.length; i++)
      intArr.push(parseFloat(strArr[i]));
    return intArr
  }

  chartDataBinding(targetValue){
    let areaChartSpline_options={
      chart: {type: 'areaspline',height:40,margin:0,borderRadius: 0},
      title: {text: ''},
      exporting: {enabled: false},
      legend: {
        enabled:false,
        layout: 'vertical',
        align: 'left',
        verticalAlign: 'top',
        x: 150,
        y: 100,
        floating: true,
        borderWidth: 0,
        background:'transparent',
        backgroundColor:'transparent'
    },
    tooltip: {
        //enabled:false,
        shared: false
        //valueSuffix: ' units'
    },
    credits: {
        enabled: false
    },
    plotOptions: {
        areaspline: {
          enabled: false,
          fillOpacity: 0.3, 
          lineOpacity:0.001,
          borderWidth: 0,
          showInLegend:false,
          marker:{
            enabled: false,
            border:0
          }
        },
    },
    series: [{
         //name: 'John',
         lineWidth: 0,
         lineColor: 'transparent',
         fillColor: {
        linearGradient: [0, 0, 0, 60],
       stops: [
          [0, 'rgb(255, 179, 0,1)'],
          //Highcharts.Color(Highcharts.getOptions().colors[3]).setOpacity(0).get('rgba')],
          [1, 'rgb(219, 102, 0,1)'//'rgb(219, 13, 13, 1)'
          //Highcharts.getOptions().colors[3]
          ]
        ],
        /*stops: [
                    [0, '#f4f4f4'],
                    [1, '#ff0000']
                ]*/
      },
        data: [3, 4, 3, 10, 4, 10, 12]
    }]
    }
    this.areaChartSpline=new Chart(areaChartSpline_options);
    this.apiSerivce._LTM_Unmanaged_Spend_Vendor_URL(this.OptionVal,this.year,this.vendorid).subscribe(
      data=>{
        debugger
        console.log("LTM_Unmanaged_Spend_Vendor_URL:"+data);
        let categoriesArray=[];
        let Seriesname=['PY','CY'];
        let color=["#ffb300","#db6600"]
        let SeriesCYColumnData = data["SeriesCYColumnData"].split(",").reduce(function(prev, curr) {
            return prev.concat(parseFloat(curr));
        }, []);
        let SeriesPYColumnData = data["SeriesPYColumnData"].split(",").reduce(function(prev, curr) {
            return prev.concat(parseFloat(curr));
        }, []);
        let Regions = data["Region"].split(",");
        let RegionsDistinct =data["Region"].split(",").reduce(function(prev,curr){
            if(!prev.includes(curr))
               prev = prev.concat(curr);
            return prev;
        },[]);
        let vendorNames=data["Vendor"].split(",");
        for(var i=0; i<RegionsDistinct.length;i++){
            debugger
            let pushVendors = [];
            for(var j=0;j<vendorNames.length;j++){
                if(Regions[j] == RegionsDistinct[i])
                {
                    pushVendors.push(vendorNames[j]);
                }
            }
            categoriesArray.push({
                "name":RegionsDistinct[i],
                "categories": pushVendors
            })
        }
        
        //let RegionsDistinct=data["Region"].split(",");
        let LTM_Unmanaged_Spend_by_Vendor_options={
          chart: {renderTo: "LTM_Unmanaged_Spend_by_Vendor",type: "column",width:500,height:250},
          credits: {enabled: false},
          exporting: {
              buttons:{
                contextButton: {
                    enabled: true
                },
                }
              },
          title: {useHTML: true,x: -10,y: 8,text: this.chartThirdHeading,style:{fontSize:"12px"}},
        series: [{
            name: 'PY',
            data: SeriesPYColumnData,
            color:"#ffb300"
        }, {
            name: 'CY',
            data: SeriesCYColumnData,
            color:"#db6600"
        }],
        xAxis: {
            categories: categoriesArray
        }
    }
    this.LTM_Unmanaged_Spend_by_Vendor=new Chart(LTM_Unmanaged_Spend_by_Vendor_options);
      },
      error => this.errorMessage=<any> error
    )
    this.apiSerivce.GetCharts_LTMUnmanSpendByMatCatByPeriod(this.OptionVal,this.year).subscribe(
      data=>{
        //let parseData=JSON.stringify(data);
       // let parseObj=JSON.parse(data).Materials;
        let dataPush=[];
        let MaterialName:string;
        let MaterialValue:number;
        let Firstmaterial={};
        let colorM=["#db6600","#ffb300","#5e2220","#ffb300","#ffb300","#aba698","#db6600"];
        let MaterialNames: string[];
        let MaterialValues: number[];
        let colorAxis={ maxColor:"#ffb300",minColor: '#db6600'}
       let points = [],
       materialP,
       materialVal,
       materialI = 0,
       regionP,
       regionI,
       vendorP,
       vendorI,
       material,
       region,
       vendor;
       data = JSON.parse(data).Materials;
   for (material in data) {
       if (data.hasOwnProperty(material)) {
           materialVal = 0;
           materialP = {
               id: 'id_' + materialI,
               name: material,
               //color:colorAxis.maxColor
           };
           regionI = 0;
           for (region in data[material]) {
               if (data[material].hasOwnProperty(region)) {
                   regionP = {
                       id: materialP.id + '_' + regionI,
                       name: region,
                       parent: materialP.id
                   };
                   points.push(regionP);
                   vendorI = 0;
                   for (vendor in data[material][region]) {
                       if (data[material][region].hasOwnProperty(vendor)) {
                           vendorP = {
                               id: regionP.id + '_' + vendorI,
                               name: vendor,
                               parent: regionP.id,
                               color:{
                                linearGradient: [0, 0, 0, 60],
                                stops: [
                                   [0, 'rgb(255, 179, 0,1)'],
                                   [1, 'rgb(219, 102, 0,1)'//'rgb(219, 13, 13, 1)'
                                   ]
                                 ]
                               },
                               value: Math.round(+data[material][region][vendor])
                           };
                           materialVal += vendorP.value;
                           points.push(vendorP);
                           vendorI = vendorI + 1;
                       }
                   }
                   regionI = regionI + 1;
               }
           }
           materialP.value = Math.round(materialVal);
           materialP.colorValue=Math.round(materialVal);
           points.push(materialP);
           materialI = materialI + 1;
       }
   }










       // console.log("dataPush:"+dataPush);
       // MaterialNames = data["MateriaNames"].split(",");
        //MaterialValues = data["MaterialValues"].split(",").reduce(function(prev, curr) {
          //return prev.concat(parseFloat(curr));
      //}, []);

        /*for(let i=0; i<MaterialNames.length; i++){
          dataPush.push(
            {
              "name":MaterialNames[i],
              "value":MaterialValues[i],
              //"color":color[i],
              "colorValue":MaterialValues[i]
          }
          )
        }*/
        let LTM_Unmanaged_Material_Category_options={
          chart: {renderTo: 'Unmanaged_material',width: 500,height: 250},
          title: {useHTML: true,x: -10,y: 8,text: this.chartFourthHeading,style:{fontSize:"12px"}},
          exporting: {enabled: false},
          credits: {enabled: false},
          colorAxis:{ maxColor:"#db6600",minColor: '#ffb300'},
          series: [{
            type: 'treemap',
            layoutAlgorithm: 'squarified',
            allowDrillToNode: true,
            levelIsConstant: false,
            animationLimit:1000,
            dataLabels: {
                enabled: false
            },
            levels: [{
                level: 1,
                dataLabels: {
                    enabled: true
                },
                borderWidth: 0
            }],
            data: points
        }],
        }
        this.LTM_Unmanaged_Material_Category=new Chart(LTM_Unmanaged_Material_Category_options);
      }
    )
    this.apiSerivce.get_LTM_Unmanaged_Spend(this.OptionVal,this.year,this.entityid).subscribe(
        data=>{
          console.log("get_ltm_data"+data);
          console.log("Entity:"+data["Categories"]);
          let LTM_Unmanaged_options={
            chart: {renderTo: 'LTM_Unmanaged',width: 500,height: 250},
            exporting: {enabled: false},
            title: {useHTML: true,x: -10,y: 8,text: this.chartSecondHeading,style:{fontSize:"12px"}},
            legend: {align: 'left',verticalAlign: 'bottom',itemStyle: {color: 'black',fontWeight: 'normal',fontSize: '12px'}   
          },
          credits: {enabled: false},
          xAxis: {categories: (data["Categories"]).split(',')},
          yAxis: [{
              labels: {
                  format: '{value} Mn',
                  style: {
                      color:"#ffb300"
                  }
              },
              title: {
                  text: 'Spend',
                  style: {
                      color:"#ffb300"
                  }
              }
          }, { // Secondary yAxis
              title: {
                  text: 'Variance',
                  style: {
                      color:"#db6600"
                  }
              },
              labels: {
                  format: '{value} %',
                  style: {
                      color:"#db6600"
                  }
              },
              opposite: true
          }],
  
          labels: {
              items: [{
                  html: '',
                  style: {
                      left: '50px',
                      top: '18px',
                      color:"#db6600"
                  }
              }]
          },
  
          series: [{
              type: 'column',
              name: 'PY',
              color: "#ffb300",
              //yAxis: 1,
              data: this.commaSeperatorNumber(data["PYColumnData"])
          }, {
              type: 'column',
              name: 'CY',
              color:"#db6600",
              //yAxis: 1,
              data: this.commaSeperatorNumber(data["CYColumnData"])
          }, {
              type: 'spline',
              name: 'Variance with PY',
              color:"#e67010",
              yAxis: 1,
              data: this.commaSeperatorNumber(data["VarWithPY"]),
              marker: {
                  lineWidth: 2,
                  lineColor:"#ffb300",
                  fillColor: 'white'
              }
          }]
          }
          this.LTM_Unmanaged=new Chart(LTM_Unmanaged_options);
        },
        error => this.errorMessage=<any> error
    )
    this.apiSerivce.get_Comparative_Analysis(this.OptionVal,this.year).subscribe(
      data=>{
        debugger
        console.log(data);
        console.log("Period:"+data["Period"]);
        let CYUnmanagedColVals: number[] = this.commaSeperatorNumber(data["CYUnmanagedCol"]);
        let CYManagedColVals: number[]=this.commaSeperatorNumber(data["CYManagedCol"]);
        let VarWithPYUnmanagedVals: number[]=this.commaSeperatorNumber(data["VarWithPYUnmanaged"]);
        let ComparativeAnalysis_options={
          chart: {type: "column",width: 500,height: 250},
          title: {
              useHTML: true,
              x: -10,y: 8,
              //text: '<a href="javascript:void(0)" onclick='+$('#sidebar').toggleClass('active')+">"+this.chartOneHeading+'</a>',
              text: '<a href="javascript:void(0)" >'+this.chartOneHeading+'</a>',
              style:{fontSize:"12px"},
              events: {click:function(){} 
          }},
          credits: {enabled: false},
          exporting:{enabled:false},
          legend: {align: 'left',verticalAlign: 'bottom',itemStyle: {color: 'black',fontWeight: 'normal',fontSize: '9px'}},
          xAxis: {categories: data["Period"].split(',')},
          yAxis: [{labels: {format: '{value} Mn',style: {color:"#ffb300"}},title: {text: 'Spend',style: {color:"#ffb300"}}
                  }, {title: {text: 'Variance',style: {color:"#db6600"}},
          labels: {format: '{value} %',style: {color:"#db6600"}}, 
          opposite: true,
    }],
    labels: {
      items: [{
          html: '',
          style: {
              left: '50px',
              top: '18px'
          }
      }]
    },
    plotOptions: {
      column: {
          stacking: 'normal'
      }
    },
    series: [{
      type: 'column',
      name: 'CY Unmanaged',
      color: "#ffb300",
      data:CYUnmanagedColVals
    }, {
      type: 'column',
      name: 'CY Managed',
      color:'#db6600',
      data:CYManagedColVals
    }, {
      type: 'spline',
      name: 'Variance with PY (Unmanaged)',
      yAxis: 1,
      color:"#e67010",
      //center: [300,-15],
      data:VarWithPYUnmanagedVals
    }, {
      type: 'pie',
      name: 'Total Spend',
      data: [{
          name: 'CY Unmanaged',
          y: parseFloat(data["PieTotSpendCYManaged"]),
          color: "#ffb300",
      }, {
          name: 'CY Managed',
          y: parseFloat(data["PieTotSpendCYUnmanaged"]),
          color:'#db6600',
      }],
      center: [300, 120],
      size: 30,
      showInLegend: false,
      dataLabels: {
          enabled: false
      }
    }]
        }        
        this.ComparativeAnalysis=new Chart(ComparativeAnalysis_options)
      },
      error => this.errorMessage=<any> error
    )
  }
}
