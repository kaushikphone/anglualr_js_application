
const AWS=require('aws-sdk');
const doclient=new AWS.DynamoDB.DocumentClient({region: 'us-east-1'});
console.log("data insert in dynamodb");


exports.handler =function(e,ctx,callback){

     var params={Item:
                 {
                      date:Date.now(),
                      message:"i live"
                 }
                ,
                TableName:'guestbook'
                };
     doclient.put(params,function(err,data){

      if(err){
	callback(err,null)
      }
      else{
          console.log(data);
	callback(err,data);
     }	

     });

}