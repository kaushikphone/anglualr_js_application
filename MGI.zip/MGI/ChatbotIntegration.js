var categoryIdVal;
var categorySelected = true;
var levelValue = '0';
var flagValue;
var levelDataValue;
var chatHistory = '';
function enableCategories(enableFlag){
	for(var categoryIdInt = 1;categoryIdInt <= 4; categoryIdInt++){
		var category_id = 'category' + categoryIdInt.toString();
		var category_btn = document.getElementById(category_id);
		if(category_btn!=undefined && category_btn!=null){
			if(enableFlag){
				category_btn.removeAttribute('disabled');
			}else{
				category_btn.setAttribute('disabled','disabled');
			}	
		}
	}
}

function selectOrDeselectCategories(categoryIdValue){
	var categoryIdIntValue = parseInt(categoryIdValue);
	for(var categoryIdInt = 1;categoryIdInt <= 4; categoryIdInt++){
		var category_id = 'category' + categoryIdInt.toString();
		var category_btn = document.getElementById(category_id);
		if(category_btn!=undefined && category_btn!=null){
			if(categoryIdIntValue===categoryIdInt){
				category_btn.setAttribute('class','chat-btn1-selected');
			}else{
				category_btn.setAttribute('class','chat-btn1');
				//category_btn.setAttribute('disabled','disabled');
			}
		}
	}

}

/* function checkTypedCharacter(e){
		e = e || window.event;
		var keyCode = e.keyCode;
		console.log('Typed Key Code::',keyCode);
		if(!(keyCode >= 48 && keyCode <= 57) && keyCode !== 8 && keyCode !== 9 ){
			e.preventDefault();
		}
	}*/
function sendOptionAsPerCategory(){
	categorySelected = false;
	fetchAndShowResponse(categoryIdVal);
	
}
let elementValuePrint;
function sendOnlyCategory(categoryIdValue){	
	levelValue = '0';
	categorySelected = true;
	elementValuePrint=$("#userMsgElmt").val();
	fetchAndShowResponse(categoryIdValue,elementValuePrint);
}
function SelectNewQuery(){
	$('#statementDiv').fadeOut('slow');
	$('#statementDiv').next().fadeOut('slow');
}
$("#userMsgElmt").on('keyup', function (e) {
	if (e.keyCode == 13) {
		$("#sendOptionButton").trigger("click");
	}
});
function fetchAndShowResponse(categoryIdValue,elementValuePrint){
	//debugger
	console.log('Category Id::',categoryIdValue);
	enableCategories(false);
	//alert(elementValuePrint);
	let Chatgirlname=$("#senderNameFld").text();
	categoryIdVal = categoryIdValue;
	$("#loaderBg,.loader").css('display','block');
	selectOrDeselectCategories(categoryIdValue);
	var apigClientFactoryObj = apigClientFactory;
	var newApiClientObj = apigClientFactoryObj.newClient({
		accessKey: '',
		secretKey: '',
		sessionToken: '',
		region: '',
		apiKey: 'OAwayLbIK3atGzZ3T0AuQ86TwTPcydBY6u3nYec6',
		//apiKey: 'V3jlGfRdcE723K9B2DPMJd3ALBTySb25uYLuMr60',
		/*defaultContentType: 'application/json',
		defaultAcceptType: 'application/json'*/
		//application/x-www-form-urlencoded
		defaultContentType: 'application/x-www-form-urlencoded',
		defaultAcceptType: 'application/x-www-form-urlencoded',
		beforeload:'alert()'		
	});
	
	var bodyDataJSON;
	console.log(bodyDataJSON);
	if(categorySelected){
		bodyDataJSON = {
			'category_id': categoryIdValue
		};
	}else{
		var userMsgElmt = document.getElementById('userMsgElmt');
		var optionVal = '';
		if(userMsgElmt!=undefined && userMsgElmt!=null && userMsgElmt.style.display==='block'){
			optionVal = userMsgElmt.value;
		}
		if(optionVal.length>0){
			//alert(optionVal);
			chatHistory += '<div class="span2 redTxt" style="text-align:left;margin-left:-1px;margin-top:10px; color:blue">Me</div>';
			chatHistory += '<span  class="chatTxt span10" style="margin-top:10px;">';
			chatHistory += optionVal;
			chatHistory += '</span>';
		}
		levelValue += (optionVal.length==0)?optionVal:'|'+optionVal;
		bodyDataJSON = {
			'category_id': categoryIdValue,
			'statement': optionVal,
			'level':levelValue
		};
		if(flagValue==1 && levelDataValue==undefined){
			bodyDataJSON = {
				'category_id': categoryIdValue,
				'statement': optionVal
			};
		}
	}
	//newApiClientObj.attr()
	newApiClientObj.chatbotForMeghnaPost({
	'x-api-key':'OAwayLbIK3atGzZ3T0AuQ86TwTPcydBY6u3nYec6'
	//'x-api-key':'V3jlGfRdcE723K9B2DPMJd3ALBTySb25uYLuMr60'
	},bodyDataJSON).then(function(response){
		$("#loaderBg,.loader").css('display','none');
		console.log(JSON.stringify(response));
		enableCategories(true);
		if(response!=undefined && response!=null && response.status==200){
			var responseData = response.data;
			if(responseData!=undefined && responseData!=null){
				flagValue = (responseData.flag != undefined && responseData.flag != null)?responseData.flag:'';
				levelDataValue = responseData.level;
				
				levelValue = (levelDataValue!=undefined && levelDataValue!=null)?levelDataValue:levelValue;
				var configDataLevelValue = (response.config!=undefined && response.config!=null 
												&& response.config.data!=undefined && response.config.data!=null)?response.config.data.level:undefined;
				console.log('FlagValue::',flagValue);
				console.log('Level Value::',levelDataValue);				
				var statementMsg = responseData.statement;
				var statementDiv = document.getElementById('statementDiv');
				var userMsgElmt = document.getElementById('userMsgElmt');
				var continueMsgDiv = document.getElementById('continueMsgDiv');
				var sendOptionButton = document.getElementById('sendOptionButton');
				var senderNameFld = document.getElementById('senderNameFld');
				if(continueMsgDiv!=undefined && continueMsgDiv!=null){
					if(levelDataValue==undefined && configDataLevelValue==undefined){
						continueMsgDiv.style.display = 'block';	
					}else{
						continueMsgDiv.style.display = 'none';
					}
				}
				if(statementMsg!=undefined && statementMsg!= null){
					chatHistory += '<div class="span2 redTxt" style="text-align:left;margin-left:-1px;margin-top:10px;">Mary</div>';
					chatHistory += '<span  class="chatTxt span10" style="margin-top:10px;">';
					chatHistory += statementMsg;
					chatHistory += '</span>';
				}
				if(statementDiv!=undefined && statementDiv!=null 
					&& statementMsg!=undefined && statementMsg!= null){
					//statementDiv.innerHTML = statementMsg;
					statementDiv.innerHTML = chatHistory.replace(/\n/g, "<br />");
					//$("#chatTxt").append("<span style='width:100%;display:block'>"+Chatgirlname+"<span><span style='width:100%; margin-left:6%'>ssss</span>");
				}	
					
				if(senderNameFld!=undefined && senderNameFld!=null){
					senderNameFld.style.display = 'block';
				}
				if(userMsgElmt!=undefined && userMsgElmt!=null){
					debugger
					if(flagValue==1){
						if(levelDataValue!=undefined && levelDataValue==='RESET'){
							userMsgElmt.setAttribute('disabled','disabled');
							$("#sendOptionButton").attr('disabled','disabled');
							$('<a href="javascript:void(0)" onclick="SelectNewQuery();" class="customSubmitbarBtn" title="Please click here for next query">Please click here for next query</a>').insertAfter("#statementDiv");
							$("#userMsgElmt").attr('placeholder', "Type question here?").attr('type', 'text').attr('onkeydown', "javascript: return event.keyCode == 69 ? true : true").show();	
						}
						else{
						userMsgElmt.removeAttribute('disabled');
						userMsgElmt.setAttribute('class','option-text-bottom');						
						userMsgElmt.style.display='block';
						userMsgElmt.setAttribute('placeholder','Type question here?');
						$("#category1").removeAttr("disabled");
						$("#statementDiv").css("display","block");
						userMsgElmt.removeAttribute('disabled');
						$("#userMsgElmt").attr('placeholder', "Type question here?").attr('type', 'text').attr('onkeydown', "javascript: return event.keyCode == 69 ? true : true").show();	
						userMsgElmt.focus();
						}
					}
					else if(flagValue==0){
						//$("#category1").attr("disabled", "disabled").addClass("DisabledBtn");
						$("#userMsgElmt").attr('placeholder', "Digits Only").attr('type', 'number').attr('min',0).attr('onkeydown', "javascript: return event.keyCode == 69 ? false : true").show();	
					}
					userMsgElmt.value = '';
					var objDiv = document.getElementById("statementDiv");
            		objDiv.scrollTop = objDiv.scrollHeight;
				}
				if(sendOptionButton!=undefined && sendOptionButton!=null){
					if(configDataLevelValue!=undefined && flagValue==1){
						sendOptionButton.setAttribute('disabled','disabled');
					}else if(flagValue==1){
						sendOptionButton.removeAttribute('disabled');
					}
				}
			}
		}
	}).catch(function(error){
		enableCategories(true);
		console.log(JSON.stringify(error));
	});
	//console.log(JSON.stringify(responseJSON));
}
let CategoryNameList=[
	{'categoryName':"Independence",'code':1},
	{'categoryName':"Joint Business Relationship",'code':"2"},
	{'categoryName':"Authorization for Services",'code':"3"},
	{'categoryName':"Anti-Money Laundering",'code':"4"},
	{'categoryName':"Conflict Check",'code':"5"},
]
/*document.addEventListener("DOMContentLoaded",event=>{
	let dynamicHtml;
	for(var i=0;i<CategoryNameList.length; i++){
		let givenCode=CategoryNameList[i].code.toString();
		//alert(givenCode);
		dynamicHtml=$("<button type='button' id='category"+CategoryNameList[i].code+"' class='chat-btn1' onclick='javascript:sendOnlyCategory('/"+givenCode+"/');' title='"+CategoryNameList[i].categoryName+"'>"+CategoryNameList[i].categoryName+"</button>");
		$("#CategoryInserted").append(dynamicHtml);
	}
});*/