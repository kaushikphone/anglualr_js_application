import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'pm-http-service-module',
  templateUrl: './http-service-module.component.html',
  styleUrls: ['./http-service-module.component.css']
})
export class HttpServiceModuleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
