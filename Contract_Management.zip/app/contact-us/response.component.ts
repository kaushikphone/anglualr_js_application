interface ItemsResponse {
  results: string[];
}
