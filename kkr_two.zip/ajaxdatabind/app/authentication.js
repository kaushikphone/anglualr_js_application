 /*authenticateUser list*/
  var userData;
  var poolData = {UserPoolId : 'us-east-1_8gW1C7PWI',ClientId : '78tpfsbdil9292r5hcihusnmia'};
  var userPool = new AWSCognito.CognitoIdentityServiceProvider.CognitoUserPool(poolData);
  var attributeList = [];
  //var dataEmail={};
  //var dataPhoneNumber={};
  var authenticationData={};
  var attributeEmail,attributePhoneNumber

  /*password Capitalization and validation*/
  function checkPasswordMatch(screenSize) {
		var passwordPolicy = [];
		passwordPolicy.lowercase = "Password must contain a lower case letter";
		passwordPolicy.uppercase = "Password must contain an upper case letter";
		passwordPolicy.number = "Password must contain a number";
		passwordPolicy.special = "Password must contain a special character";
		var passwordLength = 8;
		passwordPolicy.lengthCheck = "Password must at least 8 characters";

		var password = $("#password-" + screenSize).val();
		var username_input = $("#username-input-" + screenSize).val() != "";

		var requireLowerletter = false;
		var requireUpperletter = false;
		var requireNumber = false;
		var requireSymbol = false;
		var requireLength = false;

		if (password) {

			if (true) {
				if (/[a-z]/.test(password)) {
					$("#check-lowerletter-" + screenSize).html("&#10003;");
					$("#checkPasswordText-lowerletter-" + screenSize).html(passwordPolicy.lowercase);
					$("#checkPassword-lowerletter-" + screenSize).addClass("passwordCheck-valid-customizable").removeClass(
						"passwordCheck-notValid-customizable");
					requireLowerletter = true;
				} else {
					$("#check-lowerletter-" + screenSize).html("&#10006;");
					$("#checkPasswordText-lowerletter-" + screenSize).html(passwordPolicy.lowercase);
					$("#checkPassword-lowerletter-" + screenSize).addClass("passwordCheck-notValid-customizable").removeClass(
						"passwordCheck-valid-customizable");
					requireLowerletter = false;
				}
			} else {
				requireLowerletter = true;
			}
			if (true) {
				if (/[A-Z]/.test(password)) {
					$("#check-upperletter-" + screenSize).html("&#10003;");
					$("#checkPasswordText-upperletter-" + screenSize).html(passwordPolicy.uppercase);
					$("#checkPassword-upperletter-" + screenSize).addClass("passwordCheck-valid-customizable").removeClass(
						"passwordCheck-notValid-customizable");
					requireUpperletter = true;
				} else {
					$("#check-upperletter-" + screenSize).html("&#10006;");
					$("#checkPasswordText-upperletter-" + screenSize).html(passwordPolicy.uppercase);
					$("#checkPassword-upperletter-" + screenSize).addClass("passwordCheck-notValid-customizable").removeClass(
						"passwordCheck-valid-customizable");
					requireUpperletter = false;
				}
			} else {
				requireUpperletter = true;
			}
			if (true) {
				if (/[!|@|#|$|%|^|&|*|(|)|-|_]/.test(password)) {
					$("#check-symbols-" + screenSize).html("&#10003;");
					$("#checkPasswordText-symbols-" + screenSize).html(passwordPolicy.special);
					$("#checkPassword-symbols-" + screenSize).addClass("passwordCheck-valid-customizable").removeClass(
						"passwordCheck-notValid-customizable");
					requireSymbol = true;
				} else {
					$("#check-symbols-" + screenSize).html("&#10006;");
					$("#checkPasswordText-symbols-" + screenSize).html(passwordPolicy.special);
					$("#checkPassword-symbols-" + screenSize).addClass("passwordCheck-notValid-customizable").removeClass(
						"passwordCheck-valid-customizable");
					requireSymbol = false;
				}
			} else {
				requireSymbol = true;
			}
			if (true) {
				if (/[0-9]/.test(password)) {
					$("#check-numbers-" + screenSize).html("&#10003;");
					$("#checkPasswordText-numbers-" + screenSize).html(passwordPolicy.number);
					$("#checkPassword-numbers-" + screenSize).addClass("passwordCheck-valid-customizable").removeClass(
						"passwordCheck-notValid-customizable")
					requireNumber = true;
				} else {
					$("#check-numbers-" + screenSize).html("&#10006;");
					$("#checkPasswordText-numbers-" + screenSize).html(passwordPolicy.number);
					$("#checkPassword-numbers-" + screenSize).addClass("passwordCheck-notValid-customizable").removeClass(
						"passwordCheck-valid-customizable");
					requireNumber = false;
				}
			} else {
				requireNumber = true;
			}

			if (password.length < passwordLength) {
				$("#check-length-" + screenSize).html("&#10006;");
				$("#checkPasswordText-length-" + screenSize).html(passwordPolicy.lengthCheck);
				$("#checkPassword-length-" + screenSize).addClass("passwordCheck-notValid-customizable").removeClass(
					"passwordCheck-valid-customizable");
				requireLength = true;
			} else {
				$("#check-length-" + screenSize).html("&#10003;");
				$("#checkPasswordText-length-" + screenSize).html(passwordPolicy.lengthCheck);
				$("#checkPassword-length-" + screenSize).addClass("passwordCheck-valid-customizable").removeClass(
					"passwordCheck-notValid-customizable");
				requireLength = false;
			}
		}
		if (requireLowerletter && requireUpperletter && requireNumber && requireSymbol && username_input) {
			document.getElementById("signupButton-" + screenSize).disabled = false;
		} else {
			document.getElementById("signupButton-" + screenSize).disabled = true;
		}
	}
  /*authenticateUser list*/
function signUP(){
  userPool.signUp(UserEmail, UserPassWord, attributeList, null, function(err, result){
       if (err) {
           alert(err);
           return;
       }
       cognitoUser = result.user;
       console.log('user name is ' + cognitoUser.getUsername());
   });
}

function S4() {
    return (((1+Math.random())*0x10000)|0).toString(16).substring(1);

}
function getGUID()
{
  var guid = (S4() + S4() + "-" + S4() + "-4" + S4().substr(0,3) + "-" + S4() + "-" + S4() + S4() + S4()).toLowerCase();
  return guid;
}

 function signIn() {
    var UserEmail=$('#username').val();
    var UserPassWord=$('#password').val();

   authenticationData = {Username : UserEmail,Password : UserPassWord};

   userData = {Username : UserEmail, password : UserPassWord, Pool : userPool};
   var authenticationDetails = new AWSCognito.CognitoIdentityServiceProvider.AuthenticationDetails(authenticationData);
   var cognitoUser = new AWSCognito.CognitoIdentityServiceProvider.CognitoUser(userData);

   cognitoUser.authenticateUser(authenticationDetails, {
          onSuccess: function (result) {
              console.log('access token + ' + result.getAccessToken().getJwtToken());
              //push the GUID into the sessionToken
              sessionStorage.setItem("guid", getGUID());
              var windowLocationUrl =window.location.pathname;
              var arr = windowLocationUrl.split("/");
              alert(result);
              var Location_url="https://s3.amazonaws.com/pwc-kkr-poc/aws-glue/s3-website-v2/index.html";
              //window.location.href=Location_url;
          },

          onFailure: function(err) {
              alert(err);

          },

      });
    return true;
   //user authentication with validation

 //user authentication with validation
}
