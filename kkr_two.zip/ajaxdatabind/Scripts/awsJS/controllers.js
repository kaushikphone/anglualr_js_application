'use strict';
var s3;
var controllers = angular.module('controllers', []);
controllers.controller('UploadController', ['$scope', function($scope) {
    var accessKeyId = "AKIAJXTJWEDHX43S2VFA";
    var secretAccessKey = "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";
    var BucketName = 'pwc-kkr-poc';
    var bucketRegion = 'us-east-1';
    var awsCreds = new AWS.Credentials(accessKeyId, secretAccessKey);
    var destfileKeyName;
    var returnFromLoop = false;
    var fileNameExistsInHashMap = false;
    AWS.config.update({
        region: bucketRegion,
        credentials: awsCreds
    });
    //const s3 = new AWS.S3({apiVersion: '2006-03-01',params: {Bucket: BucketName}});
    s3 = new AWS.S3({
        apiVersion: '2006-03-01',
        params: {
            Bucket: BucketName
        }
    });
    //hash map in javascript object//

    //hash map in javascript object//
    $scope.upload = function() {
        var files = document.getElementById('fileupload').files;
        var ext = $('#fileupload').val().split(".").pop().toLowerCase();
        //bucket listing from s3
        //bucket listing from s3
        if (!files.length) {
            toastr.error('Please choose a file to upload first');
            return;
        }
        if ($.inArray(ext, ["xlsx"]) | (ext, ["xls"]) === -1) {
            toastr.error("Please upload xls or .xlsx file(s)!", "File extension mismatch");
            //alert("Please upload a .csv file!");
            return false;
        } else {
            var file = files[0];
            var fileName = file.name;

            listKeys({
                bucket: BucketName,
                prefix: 'aws-glue/source-files/excel-source-files/'
            }, function(error, keys) {
                if (error) {
                    return console.error(error);
                }
                _.each(keys, function(key) {
                    if (key.indexOf(fileName) > -1) {
                        toastr.error("File already exists . Please rename the file and try again", "Duplicate File Error");
                        returnFromLoop = true;
                        return false;
                    }

                });
                if (returnFromLoop) {
                    return false;
                } else {
                    //file key mapping
                    fileKeyMap.forEach(function(value, key) {
                        var columns = {};
                        columns.headerModel = key;
                        if (fileName.indexOf(key) > -1) {
                            //console.log(key + ' = ' + value);
                            destfileKeyName = value;
                            fileNameExistsInHashMap = true;
                            return;
                        }
                    });

                    if (!fileNameExistsInHashMap) {
                        toastr.error("Please upload valid source file(s) name", "File Mapping Mismatch");
                        return false;
                    } else {
                        s3.putObject({
                                Key: destfileKeyName + file.name,
                                Body: file
                            },
                            function(err, response) {
                                if (err) {
                                    toastr.success("Error uploading data: ", perr);
                                    console.log("Error uploading data: ", perr);
                                } else {
                                    toastr.success('File Uploaded Successfully');
                                    console.log("Successfully uploaded data to myBucket/myKey");
                                }
                            });
                    }
                    //file key mapping
                }
            });
        }
    }
    $scope.fileSizeLabel = function() {
        // Convert Bytes To MB
        return Math.round($scope.sizeLimit / 1024 / 1024) + 'MB';
    };

    $scope.uniqueString = function() {
        var text = "";
        var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

        for (var i = 0; i < 8; i++) {
            text += possible.charAt(Math.floor(Math.random() * possible.length));
        }
        return text;
    }
}]);
