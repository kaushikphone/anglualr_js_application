var accessKeyId="AKIAJXTJWEDHX43S2VFA";
var secretAccessKey ="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";
//var apigClient = apigClientFactory.newClient();
var apigClient = apigClientFactory.newClient({
  accessKey: accessKeyId,
  secretKey: secretAccessKey,
  apiKey: '2006-03-01'
});
