var fileKeyMap = new Map();
fileKeyMap.set("deal-mapping", "aws-glue/source-files/excel-source-files/deal-mapping/");
fileKeyMap.set("kpop-offshore", "aws-glue/source-files/excel-source-files/kpop-offshore/");
fileKeyMap.set("pias-data-pull-MH", "aws-glue/source-files/excel-source-files/pias-data-pull-MH/");
fileKeyMap.set("pias-data-pull", "aws-glue/source-files/excel-source-files/pias-data-pull/");
