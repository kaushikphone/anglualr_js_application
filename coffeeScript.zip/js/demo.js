
/*
app="kaushik"
tfs=true
ModalOpening = -> alert("click")
ModalOpening()
 */

(function() {
  var ModalOpening, age, app, clipPersonelModal, day, message, name, view, viewBar;

  app = "kaushik";

  ModalOpening = function() {
    return alert("hi");
  };

  clipPersonelModal = function() {
    return console.log("hello");
  };

  $('.btn-sm-block').on('click', function() {
    return ModalOpening();
  });

  if (app === "0") {
    ModalOpening();
  } else {
    clipPersonelModal();
  }

  view = (function() {
    switch (false) {
      case !target.hasClass('red'):
        return new App.RedView;
      case !target.hasClass('blue'):
        return new App.BlueView;
      case !target.is('#black'):
        return new App.BlackView;
      default:
        return null;
    }
  })();

  viewBar = (function() {
    switch (new Date().getDay()) {
      case '0':
        return day = "sunday";
      case '1':
        return day = "monday";
      case '2':
        return day = "Tuesday";
      default:
        return null;
    }
  })();

  ModalOpening();

  name = "Raju";

  age = 26;

  message = 'Hello #{name} your age is #{age}';

  console.log(message);

}).call(this);

//# sourceMappingURL=demo.map