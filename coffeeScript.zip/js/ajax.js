(function() {
  var ModalOpening;

  $(".submit").click(function() {
    return console.log("submitted!");
  });

  $.fn.extend({
    makeColor: function(options) {
      var settings;
      settings = {
        option1: "red"
      };
      settings = $.extend(settings, options);
      return this.each(function() {
        return $(this).css({
          color: settings.color
        });
      });
    }
  });

  urlList("https://demoOnline.com/gery1");

  cofflist("https://css-tricks.com/jquery-coffeescript/");

  ModalOpening = function() {
    return $.ajax({
      method: "post",
      url: urlList,
      dataType: cofflist,
      error: function(jqXHR, textStatus, errorThrown) {
        return $('body').append("AJAX Error: " + textStatus);
      },
      success: function(data, textStatus, jqXHR) {
        return $('body').append("Successful AJAX call: " + data);
      }
    });
  };

  div.animate({
    width: 200
  }, 2000);

  div.animate({
    width: 200,
    height: 200
  }, 2000);

}).call(this);

//# sourceMappingURL=ajax.map