'use strict';

var app = angular.module('angular-s3-upload', [
    'controllers',
    'directives'
]);