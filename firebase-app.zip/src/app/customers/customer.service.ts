import {Injectable} from '@angular/core';
import {AngularFireDatabase, FirebaseListObservable, FirebaseObjectObservable} from 'angularfire2/database-deprecated';
import {Customer} from './customer';
import {Observable} from "rxjs/Observable";
import "rxjs/Rx";
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/toPromise';
@Injectable()
export class CustomerService{
    private dbPath: string = '/customers';
    customer: FirebaseObjectObservable<Customer> = null;
    customers: FirebaseListObservable<Customer[]> = null;
    constructor(
        private _db: AngularFireDatabase
    ) {}
    
    //customer list data
    getCustomersList(query = {}): FirebaseListObservable<Customer[]> {
        this.customers = this._db.list('data');
        return this.customers;
      }
    //create customer list here
    createCustomer(customer: Customer): void {
        this.customers
        .push(customer)
        //.catch(error => this.handleError(error));
      }
      private handleError(error) {
        console.log(error);
      }

}