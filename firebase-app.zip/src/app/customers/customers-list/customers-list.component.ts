import { Component, OnInit } from '@angular/core';
import {CustomerService} from '../customer.service';
import {Customer} from '../customer';
import {FirebaseListObservable} from 'angularfire2/database-deprecated';
@Component({
  selector: 'app-customers-list',
  templateUrl: './customers-list.component.html',
  styleUrls: ['./customers-list.component.css'],
  providers:[]
})
export class CustomersListComponent implements OnInit {
  customerlist:string ="Customer List";
  customers: FirebaseListObservable<Customer[]>;
  constructor(
    private customerService: CustomerService
  ) { }

  ngOnInit() {
    debugger
    this.getCustomersList();
    
  }
  getCustomersList(){
    this.customers = this.customerService.getCustomersList();
  }

}
