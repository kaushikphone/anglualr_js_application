export class Customer {
    $key: string;
    name: string;
    office: string;
    profession:string;
    //active: boolean = true;
  }