import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import {AngularFireModule} from 'angularfire2';
//import {AngularFireDatabaseModule} from 'angularfire2/database';
import {AngularFireDatabase} from 'angularfire2/database-deprecated';
import { AppComponent } from './app.component';
import { environment } from '../environments/environment';
import { RouterModule } from '@angular/router';
import { CustomersListComponent } from './customers/customers-list/customers-list.component';
import { CustomerService } from './customers/customer.service';
import { CreateCustomerComponent } from './customers/create-customer/create-customer.component';


@NgModule({
  declarations: [
    AppComponent,
    CustomersListComponent,
    CreateCustomerComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    //AngularFireDatabaseModule,
    AngularFireModule.initializeApp(environment.firebase),
    RouterModule.forRoot([
      {path: '', redirectTo: '/customers', pathMatch: 'full'},
      {path: 'customers', component: CustomersListComponent},
      {path: 'add', component: CreateCustomerComponent},
      { path: '**', redirectTo: '/login', pathMatch: 'full'}, 
      {path: '*path', redirectTo: '/login'}
  ]),
  ],
  providers: [
    CustomerService,
    AngularFireDatabase
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
