/*var Request = require("request");*/
//http://ip-30-0-1-169.ap-south-1.compute.internal:11000/oozie/versions
//http://ip-30-0-1-169.ap-south-1.compute.internal:11000/oozie/v1/admin/status
/*Request.get("http://ip-30-0-1-169.ap-south-1.compute.internal:8032/oozie/versions", (error, response, body) => {
    if(error) {
        return console.dir(error);
    }
    console.dir(JSON.parse(body));
});*/
var express = require("express");
var app = express();
var nodeOozie = require("node-oozie");
app.use(express.static(__dirname + '/view'));
app.use(express.static(__dirname + '/Script'));
var config = {"protocol": "http","url": "localhost","port": "7187","version": "4.3.0"};
var oozie = nodeOozie.createClient({ config: config });
//set header//
app.all('/*', function(req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "X-Requested-With");
    res.header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE');
    res.header('Access-Control-Allow-Headers', 'Content-Type');
    next();
});
//rest api url getting
app.get('/oozie',function(req,res){
    res.setHeader('Content-Type', 'application/json');
    oozie.get('versions', function(error, response) {
        console.log(response);
        if (!error) {
            var mm = [];
            mm.push({'result': response});
            res.setHeader('Content-Type', 'application/json');
            res.status(200).send(JSON.stringify(response));
        }
        else {
            res.status(400).send(err);
        }
  });
  });
//rest api url getting
//view at node js api clling
app.get('/',function(req,res){
    res.send('index.html');
});
//view at node js api clling
app.listen(3000);
console.log("Running at Port 3000");