import { Component, OnInit,ViewChild, AfterViewInit, Input, Output } from '@angular/core';
import {ApiService} from '../HttpService/ApiService';
import { Card, RightSimulation } from '../HttpService/menu';
import {FormsModule} from '@angular/forms';
//import { CardComponent } from '../card/card.component';
//import { Chart } from 'angular-highcharts';
//import Highcharts = require('highcharts');
//import { StockChart } from 'angular-highcharts';
import * as $ from 'jquery';
import { toTypeScript } from '@angular/compiler';

//import Highcharts = require('highcharts');
//require('highcharts/highcharts-more')(Highcharts);
//require('highcharts/modules/solid-gauge')(Highcharts);
@Component({
  selector: 'pm-spend-analytic',
  templateUrl: './spend-analytic.component.html',
  styleUrls: ['./spend-analytic.component.css','./cardView.css','./sidebar.css'],
  providers:[ApiService]
})
export class SpendAnalyticComponent implements OnInit  {
   parentMessage:Card[];
   //@Input() childMessage: Card[];
   childMessage: Card[];
   OptionVal:number;
  public chartOneHeading:string="Comparative Analysis - Managed vs Unmanaged  Spend - LTM";
  public chartSecondHeading:string="LTM Unmanaged Spend by Business Entitiy";
  public chartThirdHeading:string="LTM Unmanaged Spend by Vendor";
  public chartFourthHeading:string="LTM Unmanaged Spend by Material Category";
  months = [{'name': 'Feb','value':'1'}, {'name': 'March','value':'2'}];
  selectedMonth = this.months[1];
  errorMessage: String;
  RightCardPopulate:RightSimulation[];
  _fetchCard: Card[];
  //message:string="vsl";
  //chart:Chart;
  //stock: StockChart;
  constructor(
    private apiSerivce: ApiService
  ) { 
    var testScript = document.createElement("script");  
    testScript.setAttribute("src", "/assets/js/jquery-3.3.1.min.js");
    testScript.setAttribute("src", "/assets/js/highcharts.js");
    testScript.setAttribute("src", "/assets/js/exporting.js");
    testScript.setAttribute("src", "/assets/js/export-data.js");
    testScript.setAttribute("src", "/assets/js/heatmap.js");
    testScript.setAttribute("src", "/assets/js/treemap.js");
    testScript.setAttribute("src", "/assets/js/grouped-categories.js");
    testScript.setAttribute("src", "/assets/js/app.js"); 
    document.body.appendChild(testScript);
  }

  ngOnInit() {
    this.cardDataBinding();
    this.RightSimulationChartPopulate();
    
  }
  ngAfterViewInit() {
  }

  cardDataBinding() {
    let OptionVal=$("#MonthSelector").find("option:selected").val();
    this.apiSerivce.getCardViewList(OptionVal).subscribe(
      resultArray => this.childMessage = resultArray,
      error => this.errorMessage=<any> error
    )
  }
  OnMonthChange($event){
    debugger
    this.OptionVal= $event.target.value;
    this.apiSerivce.getCardViewList(this.OptionVal).subscribe(
      resultArray => this.childMessage = resultArray,
      error => this.errorMessage=<any> error
    )
    this.parentMessage=this.childMessage;
  }
  RightSimulationChartPopulate(){
    this.apiSerivce.getRightSideBar().subscribe(
      resultArray => this.RightCardPopulate = resultArray,
      error => this.errorMessage=<any> error
    )
  }
  chartDataBinding(){
    debugger
    /*this.chart = new Chart({
      chart: {type: "column",renderTo: "container"},
      title: {
      useHTML: true,
      x: -10,
      y: 8,
      text: 'Comparative Analysis - Managed vs Unmanaged  Spend - LTM'
      //text: '<span class="chart-title"> Grouped categories <span class="chart-href"> <a href="http://www.blacklabel.pl/highcharts" target="_blank"> Black Label </a> </span> <span class="chart-subtitle">plugin by </span></span>'
  },
  credits: {
    enabled: false
},
xAxis: {
  categories: ['Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec','Jan','Feb','Mar']
},

  series: [{
    name: 'PY',
    data: [5, 3, 4, 7, 2,5],
    //stack: 'male'
}, {
    name: 'CY',
    data: [6, 4, 4, 2, 5,7],
    //stack: 'male'
}]
    });*/
  }
}
