import { Component, OnInit } from '@angular/core';
import {ApiService} from '../HttpService/ApiService';
import { Menu } from '../HttpService/menu';
import { Observable } from 'rxjs/Observable';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
@Component({
  selector: 'pm-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css'],
  providers:[ApiService]  
})
export class MenuComponent implements OnInit {
  errorMessage: String;
  dtOrgList: Array<any>;
  _fetchMenu: Menu[];
  private results: Observable<Menu[]>;
  constructor(
    private apiSerivce: ApiService,
    
  ) { }

  ngOnInit() {
    
    this.menuFetchFromJson();
  }
  menuFetchFromJson(){
    debugger
    this.apiSerivce.getMenuList()
    .subscribe(
        resultArray => this._fetchMenu = resultArray,
        error => this.errorMessage=<any> error,
    )
  }
  
  
}
