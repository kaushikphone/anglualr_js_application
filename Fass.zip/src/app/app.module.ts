import { BrowserModule } from '@angular/platform-browser';
import { NgModule, enableProdMode } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouterModule } from '@angular/router';
import { HttpModule } from '@angular/http';
import { APP_BASE_HREF, Location } from '@angular/common';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { CommonModule }   from '@angular/common';
import { ToastModule } from 'ng2-toastr';
import { HomeComponent } from './home/home.component';
import { MenuComponent } from './menu/menu.component';
import { SpendAnalyticComponent } from './spend-analytic/spend-analytic.component';
//import { CardComponent } from './card/card.component';
import { LocationStrategy, HashLocationStrategy } from '@angular/common';
//import { Ng4LoadingSpinnerModule, Ng4LoadingSpinnerService  } from 'ng4-loading-spinner';

import { AngularFontAwesomeModule } from 'angular-font-awesome';
//import { ChartModule,HIGHCHARTS_MODULES } from 'angular-highcharts';
//import stock from 'highcharts/modules/stock.src';
//import more from 'highcharts/highcharts-more.src';

/*export function highchartsModules() {
  // apply Highcharts Modules to this array
  return [stock, more];
}*/

@NgModule({
  declarations: [ 
    AppComponent,
    LoginComponent,
    HomeComponent,
    SpendAnalyticComponent,
    MenuComponent,
    //CardComponent
  ],
  imports: [
    BrowserModule,
    CommonModule,
    HttpClientModule,
    HttpModule,
    FormsModule,
    //Ng4LoadingSpinnerModule,
    AngularFontAwesomeModule,
    //ChartModule,
    BrowserAnimationsModule,
    ToastModule.forRoot(),
    //Ng4LoadingSpinnerModule.forRoot(),
    RouterModule.forRoot([
      { path: 'login', component: LoginComponent },
      { path: '', redirectTo: 'login', pathMatch: 'full'},
      {path: 'home', component: HomeComponent},
      {path: 'analytic', component: SpendAnalyticComponent},
      //{ path: 'checktool/:id', component: WelcomeComponent },
      //{path: 'validationCheck', component: ValidationCheckComponent},
      //{path: '404', component: NotFoundComponent},
      //{ path: '', redirectTo: 'welcome', pathMatch: 'full'},
      //{ path: 'contact', component: ContactUsComponent},
      //{ path: '**', redirectTo: '/404', pathMatch: 'full'},
      //{path: '*path', redirectTo: '/404'}
  ]),
  ],
  providers: [
    {provide: LocationStrategy, useClass: HashLocationStrategy}
    //{provide: HIGHCHARTS_MODULES, useFactory: highchartsModules}
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
