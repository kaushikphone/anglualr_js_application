import { Component,AfterViewInit } from '@angular/core';

@Component({
  selector: 'pm-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent  {
  template: string =`<img src="http://pa1.narvii.com/5722/2c617cd9674417d272084884b61e4bb7dd5f0b15_hq.gif" />`;
  /*ngAfterViewInit(): void {
  }*/
  title = 'Angular: Getting Started';
  constructor(){
    
  }
}
