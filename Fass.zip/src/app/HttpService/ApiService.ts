import {Injectable} from "@angular/core";
import {Http, Response, Headers,RequestOptions, RequestMethod} from "@angular/http";
import { HttpClient } from '@angular/common/http';
import {Observable} from "rxjs/Observable";
import "rxjs/Rx";
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/toPromise';
import {Menu, Card ,RightSimulation} from "./menu";
//import { Ng4LoadingSpinnerService } from "ng4-loading-spinner";

@Injectable()
    export class ApiService{
        baseURL:string="http://10.31.101.78:7001";
        private _menuURL=this.baseURL+"/Api/values/getleftmenu";
        private _RightSimulationUrl="/api/menu/rightSideBar.json";
        constructor(
            private _http: Http,
            //private spinnerService: Ng4LoadingSpinnerService
            
        ) {}
        //loading spinner
        startLoadingSpinner() {
            //this.spinnerService.show();
            setTimeout(function() {
              //this.spinnerService.hide();
            }.bind(this), 3000);
          }
        //Menu data binding from dataBase//
        getMenuList():Observable<Menu[]>{
            this.startLoadingSpinner()
            return this._http.get(this._menuURL).map(this.extractMenuData).catch(this.handleError);
        }
        private extractMenuData(response: Response){
            let body=<Menu[]>response.json();
            console.log(body);
            return body ||[];
        } 
        //card view binding from web api//
        getCardViewList(OptionVal):Observable<Card[]>{
            this.startLoadingSpinner();
            return this._http.get(this.baseURL+"/Api/values/getcardsbyperiod?period="+OptionVal).map(this.extractCardData).catch(this.handleError);
        }
        private extractCardData(response: Response){
            let cardData=<Card[]>response.json();
            console.log(cardData);
            return cardData ||[];
        }
        //SideBar binding from local json
        getRightSideBar():Observable<RightSimulation[]>{
            this.startLoadingSpinner();
            return this._http.get(this._RightSimulationUrl).map(this.extractSimulation).catch(this.handleError);
        }
        private extractSimulation(response: Response){
            let SimulationData=<RightSimulation[]>response.json();
            console.log(SimulationData);
            return SimulationData ||[];
        }
        private handleError(error: Response) {
            return Observable.throw(error.statusText);
        }
            private handleErrorPromise (error: Response | any) {
                console.error(error.message || error);
                return Promise.reject(error.message || error);
                }
        
    }

