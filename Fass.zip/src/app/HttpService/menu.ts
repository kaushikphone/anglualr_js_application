export interface Menu{
    menuId: string;
    menuImage: string;
    menuName: string;
    pageName:string;
    isEnable:boolean;
}
export interface Card{
    CardID:number;
    Year:number;
    Period:number;
    CardName:string;
    CardIcon:string;
    GraphPath:string;
}

export interface RightSimulation{
    simulationImage:string;
    simulationStateIncrease:string;
    simulationStateDecrease:string;
}